export const translations = {
  en: {
    // Navigation & General
    welcome: 'Welcome to EduAI',
    tagline: 'Education in Every Pocket',
    whyDifferent: 'Plagiarism-free, original content crafted by educators',
    login: 'Login',
    signup: 'Sign Up',
    logout: 'Logout',
    
    // User Management
    name: 'Full Name',
    email: 'Email Address',
    password: 'Password',
    grade: 'Grade Level',
    preferredLanguage: 'Preferred Language',
    githubUsername: 'GitHub Username (Optional)',
    subject: 'Subject',
    school: 'School Name',
    bio: 'Bio',
    experience: 'Years of Experience',
    
    // User Types
    student: 'Student',
    teacher: 'Teacher',
    registerAs: 'Register as',
    teacherProfile: 'Teacher Profile',
    studentProfile: 'Student Profile',
    
    // Dashboard & Navigation
    dashboard: 'Dashboard',
    readingCoach: 'Reading Coach',
    homeworkHelper: 'Homework Helper',
    lifeSkills: 'Life Skills',
    offlineContent: 'Offline Content',
    parentUpdates: 'Parent Updates',
    assignments: 'Assignments',
    scoreboard: 'Scoreboard',
    analytics: 'Analytics',
    myTeachers: 'My Teachers',
    myStudents: 'My Students',
    
    // Progress & Stats
    streakDays: 'Day Streak',
    lessonsCompleted: 'Lessons Completed',
    readingLevel: 'Reading Level',
    mathLevel: 'Math Level',
    scienceLevel: 'Science Level',
    actualUsageTime: 'Actual Study Time',
    realTimeProgress: 'Real-time Progress',
    overallProgress: 'Overall Progress',
    
    // Actions
    startReading: 'Start Reading Practice',
    scanHomework: 'Scan Homework Problem',
    downloadLessons: 'Download Lessons',
    sendUpdate: 'Send Parent Update',
    submitAssignment: 'Submit Assignment',
    viewProgress: 'View Progress',
    createAssignment: 'Create Assignment',
    gradeSubmission: 'Grade Submission',
    
    // Time-based greetings
    goodMorning: 'Good morning',
    goodAfternoon: 'Good afternoon',
    goodEvening: 'Good evening',
    
    // Content & Learning
    continueReading: 'Continue Reading',
    practiceProblems: 'Practice Problems',
    healthLessons: 'Health Lessons',
    nutritionTips: 'Nutrition Tips',
    codingChallenges: 'Coding Challenges',
    
    // Feedback & Communication
    provideFeedback: 'Provide Feedback',
    contactTeacher: 'Contact Teacher',
    messageParents: 'Message Parents',
    viewFeedback: 'View Feedback',
    
    // Offline & Connectivity
    offlineMode: 'Offline Mode',
    syncProgress: 'Sync Progress',
    downloadContent: 'Download Content',
    
    // Security & Privacy
    secureLogin: 'Secure Login',
    dataProtection: 'Your data is protected',
    privacyPolicy: 'Privacy Policy'
  },
  es: {
    // Navigation & General
    welcome: 'Bienvenido a EduAI',
    tagline: 'Educación en Cada Bolsillo',
    whyDifferent: 'Contenido original libre de plagio, creado por educadores',
    login: 'Iniciar Sesión',
    signup: 'Registrarse',
    logout: 'Cerrar Sesión',
    
    // User Management
    name: 'Nombre Completo',
    email: 'Correo Electrónico',
    password: 'Contraseña',
    grade: 'Nivel de Grado',
    preferredLanguage: 'Idioma Preferido',
    githubUsername: 'Usuario de GitHub (Opcional)',
    subject: 'Materia',
    school: 'Nombre de la Escuela',
    bio: 'Biografía',
    experience: 'Años de Experiencia',
    
    // User Types
    student: 'Estudiante',
    teacher: 'Profesor',
    registerAs: 'Registrarse como',
    teacherProfile: 'Perfil del Profesor',
    studentProfile: 'Perfil del Estudiante',
    
    // Dashboard & Navigation
    dashboard: 'Panel Principal',
    readingCoach: 'Entrenador de Lectura',
    homeworkHelper: 'Ayudante de Tareas',
    lifeSkills: 'Habilidades para la Vida',
    offlineContent: 'Contenido Sin Conexión',
    parentUpdates: 'Actualizaciones para Padres',
    assignments: 'Tareas',
    scoreboard: 'Tabla de Puntuaciones',
    analytics: 'Análisis',
    myTeachers: 'Mis Profesores',
    myStudents: 'Mis Estudiantes',
    
    // Progress & Stats
    streakDays: 'Días Consecutivos',
    lessonsCompleted: 'Lecciones Completadas',
    readingLevel: 'Nivel de Lectura',
    mathLevel: 'Nivel de Matemáticas',
    scienceLevel: 'Nivel de Ciencias',
    actualUsageTime: 'Tiempo Real de Estudio',
    realTimeProgress: 'Progreso en Tiempo Real',
    overallProgress: 'Progreso General',
    
    // Actions
    startReading: 'Comenzar Práctica de Lectura',
    scanHomework: 'Escanear Problema de Tarea',
    downloadLessons: 'Descargar Lecciones',
    sendUpdate: 'Enviar Actualización a Padres',
    submitAssignment: 'Enviar Tarea',
    viewProgress: 'Ver Progreso',
    createAssignment: 'Crear Tarea',
    gradeSubmission: 'Calificar Envío',
    
    // Time-based greetings
    goodMorning: 'Buenos días',
    goodAfternoon: 'Buenas tardes',
    goodEvening: 'Buenas noches',
    
    // Content & Learning
    continueReading: 'Continuar Leyendo',
    practiceProblems: 'Problemas de Práctica',
    healthLessons: 'Lecciones de Salud',
    nutritionTips: 'Consejos de Nutrición',
    codingChallenges: 'Desafíos de Programación',
    
    // Feedback & Communication
    provideFeedback: 'Proporcionar Comentarios',
    contactTeacher: 'Contactar Profesor',
    messageParents: 'Mensaje a Padres',
    viewFeedback: 'Ver Comentarios',
    
    // Offline & Connectivity
    offlineMode: 'Modo Sin Conexión',
    syncProgress: 'Sincronizar Progreso',
    downloadContent: 'Descargar Contenido',
    
    // Security & Privacy
    secureLogin: 'Inicio de Sesión Seguro',
    dataProtection: 'Tus datos están protegidos',
    privacyPolicy: 'Política de Privacidad'
  },
  fr: {
    // Navigation & General
    welcome: 'Bienvenue sur EduAI',
    tagline: 'L\'Éducation dans Chaque Poche',
    whyDifferent: 'Contenu original sans plagiat, créé par des éducateurs',
    login: 'Se Connecter',
    signup: 'S\'inscrire',
    logout: 'Se Déconnecter',
    
    // User Management
    name: 'Nom Complet',
    email: 'Adresse Email',
    password: 'Mot de Passe',
    grade: 'Niveau Scolaire',
    preferredLanguage: 'Langue Préférée',
    githubUsername: 'Nom d\'utilisateur GitHub (Optionnel)',
    subject: 'Matière',
    school: 'Nom de l\'École',
    bio: 'Biographie',
    experience: 'Années d\'Expérience',
    
    // User Types
    student: 'Étudiant',
    teacher: 'Professeur',
    registerAs: 'S\'inscrire en tant que',
    teacherProfile: 'Profil du Professeur',
    studentProfile: 'Profil de l\'Étudiant',
    
    // Dashboard & Navigation
    dashboard: 'Tableau de Bord',
    readingCoach: 'Coach de Lecture',
    homeworkHelper: 'Aide aux Devoirs',
    lifeSkills: 'Compétences de Vie',
    offlineContent: 'Contenu Hors Ligne',
    parentUpdates: 'Mises à Jour Parents',
    assignments: 'Devoirs',
    scoreboard: 'Tableau des Scores',
    analytics: 'Analyses',
    myTeachers: 'Mes Professeurs',
    myStudents: 'Mes Étudiants',
    
    // Progress & Stats
    streakDays: 'Jours Consécutifs',
    lessonsCompleted: 'Leçons Terminées',
    readingLevel: 'Niveau de Lecture',
    mathLevel: 'Niveau de Mathématiques',
    scienceLevel: 'Niveau de Sciences',
    actualUsageTime: 'Temps d\'Étude Réel',
    realTimeProgress: 'Progrès en Temps Réel',
    overallProgress: 'Progrès Global',
    
    // Actions
    startReading: 'Commencer la Pratique de Lecture',
    scanHomework: 'Scanner le Problème de Devoirs',
    downloadLessons: 'Télécharger les Leçons',
    sendUpdate: 'Envoyer une Mise à Jour Parent',
    submitAssignment: 'Soumettre le Devoir',
    viewProgress: 'Voir les Progrès',
    createAssignment: 'Créer un Devoir',
    gradeSubmission: 'Noter la Soumission',
    
    // Time-based greetings
    goodMorning: 'Bonjour',
    goodAfternoon: 'Bon après-midi',
    goodEvening: 'Bonsoir',
    
    // Content & Learning
    continueReading: 'Continuer la Lecture',
    practiceProblems: 'Problèmes de Pratique',
    healthLessons: 'Leçons de Santé',
    nutritionTips: 'Conseils Nutritionnels',
    codingChallenges: 'Défis de Programmation',
    
    // Feedback & Communication
    provideFeedback: 'Fournir des Commentaires',
    contactTeacher: 'Contacter le Professeur',
    messageParents: 'Message aux Parents',
    viewFeedback: 'Voir les Commentaires',
    
    // Offline & Connectivity
    offlineMode: 'Mode Hors Ligne',
    syncProgress: 'Synchroniser les Progrès',
    downloadContent: 'Télécharger le Contenu',
    
    // Security & Privacy
    secureLogin: 'Connexion Sécurisée',
    dataProtection: 'Vos données sont protégées',
    privacyPolicy: 'Politique de Confidentialité'
  },
  sw: {
    // Navigation & General
    welcome: 'Karibu EduAI',
    tagline: 'Elimu katika Kila Mfuko',
    whyDifferent: 'Maudhui asili yasiyonakiliwa, yaliyotengenezwa na walimu',
    login: 'Ingia',
    signup: 'Jiunge',
    logout: 'Toka',
    
    // User Management
    name: 'Jina Kamili',
    email: 'Anwani ya Barua Pepe',
    password: 'Nenosiri',
    grade: 'Kiwango cha Darasa',
    preferredLanguage: 'Lugha Unayopendelea',
    githubUsername: 'Jina la Mtumiaji wa GitHub (Si Lazima)',
    subject: 'Somo',
    school: 'Jina la Shule',
    bio: 'Maelezo',
    experience: 'Miaka ya Uzoefu',
    
    // User Types
    student: 'Mwanafunzi',
    teacher: 'Mwalimu',
    registerAs: 'Jiunge kama',
    teacherProfile: 'Wasifu wa Mwalimu',
    studentProfile: 'Wasifu wa Mwanafunzi',
    
    // Dashboard & Navigation
    dashboard: 'Dashibodi',
    readingCoach: 'Mkocha wa Kusoma',
    homeworkHelper: 'Msaidizi wa Kazi za Nyumbani',
    lifeSkills: 'Ujuzi wa Maisha',
    offlineContent: 'Maudhui Nje ya Mtandao',
    parentUpdates: 'Masasisho ya Wazazi',
    assignments: 'Kazi za Shule',
    scoreboard: 'Ubao wa Alama',
    analytics: 'Uchambuzi',
    myTeachers: 'Walimu Wangu',
    myStudents: 'Wanafunzi Wangu',
    
    // Progress & Stats
    streakDays: 'Siku Mfululizo',
    lessonsCompleted: 'Masomo Yaliyokamilika',
    readingLevel: 'Kiwango cha Kusoma',
    mathLevel: 'Kiwango cha Hisabati',
    scienceLevel: 'Kiwango cha Sayansi',
    actualUsageTime: 'Muda Halisi wa Kusoma',
    realTimeProgress: 'Maendeleo ya Wakati Halisi',
    overallProgress: 'Maendeleo ya Jumla',
    
    // Actions
    startReading: 'Anza Mazoezi ya Kusoma',
    scanHomework: 'Chagua Tatizo la Kazi za Nyumbani',
    downloadLessons: 'Pakua Masomo',
    sendUpdate: 'Tuma Masasisho ya Mzazi',
    submitAssignment: 'Wasilisha Kazi',
    viewProgress: 'Ona Maendeleo',
    createAssignment: 'Tengeneza Kazi',
    gradeSubmission: 'Kadiria Uwasilishaji',
    
    // Time-based greetings
    goodMorning: 'Habari za asubuhi',
    goodAfternoon: 'Habari za mchana',
    goodEvening: 'Habari za jioni',
    
    // Content & Learning
    continueReading: 'Endelea Kusoma',
    practiceProblems: 'Matatizo ya Mazoezi',
    healthLessons: 'Masomo ya Afya',
    nutritionTips: 'Vidokezo vya Lishe',
    codingChallenges: 'Changamoto za Programu',
    
    // Feedback & Communication
    provideFeedback: 'Toa Maoni',
    contactTeacher: 'Wasiliana na Mwalimu',
    messageParents: 'Ujumbe kwa Wazazi',
    viewFeedback: 'Ona Maoni',
    
    // Offline & Connectivity
    offlineMode: 'Hali ya Nje ya Mtandao',
    syncProgress: 'Sawazisha Maendeleo',
    downloadContent: 'Pakua Maudhui',
    
    // Security & Privacy
    secureLogin: 'Kuingia Kwa Usalama',
    dataProtection: 'Data yako inalindwa',
    privacyPolicy: 'Sera ya Faragha'
  },
  ar: {
    // Navigation & General
    welcome: 'مرحباً بك في EduAI',
    tagline: 'التعليم في كل جيب',
    whyDifferent: 'محتوى أصلي خالٍ من الانتحال، من إعداد المعلمين',
    login: 'تسجيل الدخول',
    signup: 'إنشاء حساب',
    logout: 'تسجيل الخروج',
    
    // User Management
    name: 'الاسم الكامل',
    email: 'عنوان البريد الإلكتروني',
    password: 'كلمة المرور',
    grade: 'مستوى الصف',
    preferredLanguage: 'اللغة المفضلة',
    githubUsername: 'اسم المستخدم في GitHub (اختياري)',
    subject: 'المادة',
    school: 'اسم المدرسة',
    bio: 'السيرة الذاتية',
    experience: 'سنوات الخبرة',
    
    // User Types
    student: 'طالب',
    teacher: 'معلم',
    registerAs: 'التسجيل كـ',
    teacherProfile: 'ملف المعلم',
    studentProfile: 'ملف الطالب',
    
    // Dashboard & Navigation
    dashboard: 'لوحة التحكم',
    readingCoach: 'مدرب القراءة',
    homeworkHelper: 'مساعد الواجبات',
    lifeSkills: 'مهارات الحياة',
    offlineContent: 'المحتوى غير المتصل',
    parentUpdates: 'تحديثات الوالدين',
    assignments: 'الواجبات',
    scoreboard: 'لوحة النتائج',
    analytics: 'التحليلات',
    myTeachers: 'معلميّ',
    myStudents: 'طلابي',
    
    // Progress & Stats
    streakDays: 'أيام متتالية',
    lessonsCompleted: 'الدروس المكتملة',
    readingLevel: 'مستوى القراءة',
    mathLevel: 'مستوى الرياضيات',
    scienceLevel: 'مستوى العلوم',
    actualUsageTime: 'وقت الدراسة الفعلي',
    realTimeProgress: 'التقدم في الوقت الفعلي',
    overallProgress: 'التقدم العام',
    
    // Actions
    startReading: 'بدء ممارسة القراءة',
    scanHomework: 'مسح مشكلة الواجب',
    downloadLessons: 'تحميل الدروس',
    sendUpdate: 'إرسال تحديث للوالدين',
    submitAssignment: 'تقديم الواجب',
    viewProgress: 'عرض التقدم',
    createAssignment: 'إنشاء واجب',
    gradeSubmission: 'تقييم التقديم',
    
    // Time-based greetings
    goodMorning: 'صباح الخير',
    goodAfternoon: 'مساء الخير',
    goodEvening: 'مساء الخير',
    
    // Content & Learning
    continueReading: 'متابعة القراءة',
    practiceProblems: 'مسائل التدريب',
    healthLessons: 'دروس الصحة',
    nutritionTips: 'نصائح التغذية',
    codingChallenges: 'تحديات البرمجة',
    
    // Feedback & Communication
    provideFeedback: 'تقديم ملاحظات',
    contactTeacher: 'الاتصال بالمعلم',
    messageParents: 'رسالة للوالدين',
    viewFeedback: 'عرض الملاحظات',
    
    // Offline & Connectivity
    offlineMode: 'الوضع غير المتصل',
    syncProgress: 'مزامنة التقدم',
    downloadContent: 'تحميل المحتوى',
    
    // Security & Privacy
    secureLogin: 'تسجيل دخول آمن',
    dataProtection: 'بياناتك محمية',
    privacyPolicy: 'سياسة الخصوصية'
  },
  pt: {
    // Navigation & General
    welcome: 'Bem-vindo ao EduAI',
    tagline: 'Educação em Cada Bolso',
    whyDifferent: 'Conteúdo original livre de plágio, criado por educadores',
    login: 'Entrar',
    signup: 'Cadastrar',
    logout: 'Sair',
    
    // User Management
    name: 'Nome Completo',
    email: 'Endereço de Email',
    password: 'Senha',
    grade: 'Nível da Série',
    preferredLanguage: 'Idioma Preferido',
    githubUsername: 'Nome de Usuário GitHub (Opcional)',
    subject: 'Matéria',
    school: 'Nome da Escola',
    bio: 'Biografia',
    experience: 'Anos de Experiência',
    
    // User Types
    student: 'Estudante',
    teacher: 'Professor',
    registerAs: 'Cadastrar como',
    teacherProfile: 'Perfil do Professor',
    studentProfile: 'Perfil do Estudante',
    
    // Dashboard & Navigation
    dashboard: 'Painel',
    readingCoach: 'Treinador de Leitura',
    homeworkHelper: 'Ajudante de Lição',
    lifeSkills: 'Habilidades para a Vida',
    offlineContent: 'Conteúdo Offline',
    parentUpdates: 'Atualizações dos Pais',
    assignments: 'Tarefas',
    scoreboard: 'Placar',
    analytics: 'Análises',
    myTeachers: 'Meus Professores',
    myStudents: 'Meus Estudantes',
    
    // Progress & Stats
    streakDays: 'Dias Consecutivos',
    lessonsCompleted: 'Lições Completadas',
    readingLevel: 'Nível de Leitura',
    mathLevel: 'Nível de Matemática',
    scienceLevel: 'Nível de Ciências',
    actualUsageTime: 'Tempo Real de Estudo',
    realTimeProgress: 'Progresso em Tempo Real',
    overallProgress: 'Progresso Geral',
    
    // Actions
    startReading: 'Iniciar Prática de Leitura',
    scanHomework: 'Escanear Problema da Lição',
    downloadLessons: 'Baixar Lições',
    sendUpdate: 'Enviar Atualização aos Pais',
    submitAssignment: 'Enviar Tarefa',
    viewProgress: 'Ver Progresso',
    createAssignment: 'Criar Tarefa',
    gradeSubmission: 'Avaliar Submissão',
    
    // Time-based greetings
    goodMorning: 'Bom dia',
    goodAfternoon: 'Boa tarde',
    goodEvening: 'Boa noite',
    
    // Content & Learning
    continueReading: 'Continuar Lendo',
    practiceProblems: 'Problemas de Prática',
    healthLessons: 'Lições de Saúde',
    nutritionTips: 'Dicas de Nutrição',
    codingChallenges: 'Desafios de Programação',
    
    // Feedback & Communication
    provideFeedback: 'Fornecer Feedback',
    contactTeacher: 'Contatar Professor',
    messageParents: 'Mensagem aos Pais',
    viewFeedback: 'Ver Feedback',
    
    // Offline & Connectivity
    offlineMode: 'Modo Offline',
    syncProgress: 'Sincronizar Progresso',
    downloadContent: 'Baixar Conteúdo',
    
    // Security & Privacy
    secureLogin: 'Login Seguro',
    dataProtection: 'Seus dados estão protegidos',
    privacyPolicy: 'Política de Privacidade'
  },
  hi: {
    // Navigation & General
    welcome: 'EduAI में आपका स्वागत है',
    tagline: 'हर जेब में शिक्षा',
    whyDifferent: 'मौलिक सामग्री जो चोरी-मुक्त है, शिक्षकों द्वारा तैयार',
    login: 'लॉग इन',
    signup: 'साइन अप',
    logout: 'लॉग आउट',
    
    // User Management
    name: 'पूरा नाम',
    email: 'ईमेल पता',
    password: 'पासवर्ड',
    grade: 'कक्षा स्तर',
    preferredLanguage: 'पसंदीदा भाषा',
    githubUsername: 'GitHub उपयोगकर्ता नाम (वैकल्पिक)',
    subject: 'विषय',
    school: 'स्कूल का नाम',
    bio: 'जीवनी',
    experience: 'अनुभव के वर्ष',
    
    // User Types
    student: 'छात्र',
    teacher: 'शिक्षक',
    registerAs: 'के रूप में पंजीकरण',
    teacherProfile: 'शिक्षक प्रोफ़ाइल',
    studentProfile: 'छात्र प्रोफ़ाइल',
    
    // Dashboard & Navigation
    dashboard: 'डैशबोर्ड',
    readingCoach: 'पठन कोच',
    homeworkHelper: 'गृहकार्य सहायक',
    lifeSkills: 'जीवन कौशल',
    offlineContent: 'ऑफ़लाइन सामग्री',
    parentUpdates: 'माता-पिता अपडेट',
    assignments: 'असाइनमेंट',
    scoreboard: 'स्कोरबोर्ड',
    analytics: 'विश्लेषण',
    myTeachers: 'मेरे शिक्षक',
    myStudents: 'मेरे छात्र',
    
    // Progress & Stats
    streakDays: 'लगातार दिन',
    lessonsCompleted: 'पूर्ण पाठ',
    readingLevel: 'पठन स्तर',
    mathLevel: 'गणित स्तर',
    scienceLevel: 'विज्ञान स्तर',
    actualUsageTime: 'वास्तविक अध्ययन समय',
    realTimeProgress: 'वास्तविक समय प्रगति',
    overallProgress: 'समग्र प्रगति',
    
    // Actions
    startReading: 'पठन अभ्यास शुरू करें',
    scanHomework: 'गृहकार्य समस्या स्कैन करें',
    downloadLessons: 'पाठ डाउनलोड करें',
    sendUpdate: 'माता-पिता अपडेट भेजें',
    submitAssignment: 'असाइनमेंट जमा करें',
    viewProgress: 'प्रगति देखें',
    createAssignment: 'असाइनमेंट बनाएं',
    gradeSubmission: 'सबमिशन ग्रेड करें',
    
    // Time-based greetings
    goodMorning: 'सुप्रभात',
    goodAfternoon: 'शुभ दोपहर',
    goodEvening: 'शुभ संध्या',
    
    // Content & Learning
    continueReading: 'पढ़ना जारी रखें',
    practiceProblems: 'अभ्यास समस्याएं',
    healthLessons: 'स्वास्थ्य पाठ',
    nutritionTips: 'पोषण सुझाव',
    codingChallenges: 'कोडिंग चुनौतियां',
    
    // Feedback & Communication
    provideFeedback: 'फीडबैक दें',
    contactTeacher: 'शिक्षक से संपर्क करें',
    messageParents: 'माता-पिता को संदेश',
    viewFeedback: 'फीडबैक देखें',
    
    // Offline & Connectivity
    offlineMode: 'ऑफ़लाइन मोड',
    syncProgress: 'प्रगति सिंक करें',
    downloadContent: 'सामग्री डाउनलोड करें',
    
    // Security & Privacy
    secureLogin: 'सुरक्षित लॉगिन',
    dataProtection: 'आपका डेटा सुरक्षित है',
    privacyPolicy: 'गोपनीयता नीति'
  }
};