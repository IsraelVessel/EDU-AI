export interface Student {
  id: string;
  name: string;
  email: string;
  grade: string;
  preferredLanguage: string;
  joinDate: string;
  teacherId?: string;
  githubUsername?: string;
  progress: {
    readingLevel: number;
    mathLevel: number;
    scienceLevel: number;
    completedLessons: number;
    totalLessons: number;
    streakDays: number;
    actualUsageTime: number; // in minutes
    lastActiveTime: string;
    gradeSpecificProgress: Record<string, number>;
  };
  assignments: Assignment[];
  realTimeActivity: ActivityLog[];
}

export interface Teacher {
  id: string;
  name: string;
  email: string;
  subject: string;
  school: string;
  githubUsername: string;
  joinDate: string;
  students: string[]; // student IDs
  classes: Class[];
  profile: {
    bio: string;
    experience: number;
    qualifications: string[];
    avatar?: string;
  };
}

export interface Class {
  id: string;
  name: string;
  grade: string;
  subject: string;
  teacherId: string;
  studentIds: string[];
  assignments: Assignment[];
  scoreboard: ScoreboardEntry[];
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  subject: string;
  grade: string;
  dueDate: string;
  githubRepoUrl: string;
  maxScore: number;
  submissions: AssignmentSubmission[];
  autoGrading: boolean;
  rubric: GradingRubric[];
}

export interface AssignmentSubmission {
  id: string;
  studentId: string;
  assignmentId: string;
  githubPullRequestUrl: string;
  submittedAt: string;
  score?: number;
  feedback?: string;
  autoGradedReport?: AutoGradingReport;
  teacherReviewed: boolean;
}

export interface AutoGradingReport {
  overallScore: number;
  codeQuality: number;
  functionality: number;
  documentation: number;
  testCoverage: number;
  feedback: string[];
  suggestions: string[];
}

export interface GradingRubric {
  criteria: string;
  maxPoints: number;
  description: string;
}

export interface ScoreboardEntry {
  studentId: string;
  studentName: string;
  totalScore: number;
  averageScore: number;
  completedAssignments: number;
  rank: number;
  badges: Badge[];
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earnedAt: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  timestamp: string;
  duration: number; // in minutes
  module: string;
  details: Record<string, any>;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  type: 'reading' | 'math' | 'science' | 'health' | 'nutrition' | 'coding';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: number; // in minutes
  content: string;
  isCompleted: boolean;
  isDownloaded: boolean;
  targetGrades: string[];
  prerequisites: string[];
  learningObjectives: string[];
  assessments: Assessment[];
}

export interface Assessment {
  id: string;
  type: 'quiz' | 'practical' | 'project';
  questions: Question[];
  passingScore: number;
}

export interface Question {
  id: string;
  text: string;
  type: 'multiple-choice' | 'true-false' | 'short-answer' | 'coding';
  options?: string[];
  correctAnswer: string;
  explanation: string;
  points: number;
}

export interface ReadingExercise {
  id: string;
  title: string;
  text: string;
  difficulty: string;
  targetWords: string[];
  completed: boolean;
  grade: string;
  comprehensionQuestions: Question[];
}

export interface HomeworkProblem {
  id: string;
  subject: 'math' | 'science' | 'coding';
  problem: string;
  solution: string;
  steps: string[];
  imageUrl?: string;
  grade: string;
  difficulty: string;
}

export interface ProgressData {
  date: string;
  readingScore: number;
  mathScore: number;
  scienceScore: number;
  lessonsCompleted: number;
  actualStudyTime: number;
}

export type Language = 'en' | 'es' | 'fr' | 'sw' | 'ar' | 'pt' | 'hi';

export interface ContentPack {
  id: string;
  name: string;
  description: string;
  size: string;
  lessons: number;
  language: Language;
  targetGrades: string[];
  isDownloaded: boolean;
  downloadProgress: number;
  lastUpdated: string;
  isPlagiarismFree: boolean;
  contentSource: 'original' | 'curated' | 'verified';
}

export interface ParentUpdate {
  id: string;
  studentName: string;
  parentPhone: string;
  message: string;
  type: 'progress' | 'achievement' | 'reminder' | 'assignment';
  sentAt: string;
  deliveryStatus: 'sent' | 'delivered' | 'failed';
}

export interface UserFeedback {
  id: string;
  userId: string;
  userType: 'student' | 'teacher';
  rating: number;
  comment: string;
  category: 'content' | 'usability' | 'features' | 'performance';
  submittedAt: string;
  status: 'pending' | 'reviewed' | 'resolved';
}

export interface RealTimeSession {
  userId: string;
  startTime: string;
  currentModule: string;
  isActive: boolean;
  heartbeat: string;
}

export interface GradeSpecificContent {
  grade: string;
  subjects: {
    math: Lesson[];
    science: Lesson[];
    reading: ReadingExercise[];
    health: Lesson[];
  };
  assessments: Assessment[];
  difficulty: 'elementary' | 'middle' | 'high';
}

export interface TeacherStudentInteraction {
  id: string;
  teacherId: string;
  studentId: string;
  type: 'message' | 'feedback' | 'assignment' | 'grade';
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface SchoolAnalytics {
  schoolId: string;
  totalStudents: number;
  totalTeachers: number;
  averageProgress: number;
  topPerformers: ScoreboardEntry[];
  subjectPerformance: Record<string, number>;
  engagementMetrics: {
    dailyActiveUsers: number;
    weeklyActiveUsers: number;
    averageSessionTime: number;
    retentionRate: number;
  };
}