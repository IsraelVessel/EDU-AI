import React from 'react';
import { BookOpen, Calculator, Heart, Download, MessageSquare, TrendingUp, Award, Clock, Code, Users, BarChart3, Zap } from 'lucide-react';
import { Student, Language } from '../types';
import { translations } from '../i18n';

interface DashboardProps {
  student: Student;
  greeting: string;
  currentLanguage: Language;
  realTimeSession?: any;
}

const Dashboard: React.FC<DashboardProps> = ({ student, greeting, currentLanguage, realTimeSession }) => {
  const t = translations[currentLanguage];

  // Calculate real-time progress based on actual usage
  const calculateRealProgress = () => {
    const baseProgress = (student.progress.completedLessons / student.progress.totalLessons) * 100;
    const usageBonus = Math.min((student.progress.actualUsageTime / 60) * 2, 20); // Max 20% bonus for usage
    return Math.min(baseProgress + usageBonus, 100);
  };

  // Get grade-specific content recommendations
  const getGradeSpecificActions = () => {
    const gradeNum = parseInt(student.grade.replace('Grade ', ''));
    
    if (gradeNum <= 5) {
      return [
        {
          id: 'reading',
          title: 'Picture Book Reading',
          description: 'Practice reading with colorful picture books',
          icon: BookOpen,
          color: 'from-blue-500 to-blue-600',
          progress: Math.floor((student.progress.readingLevel / 10) * 100)
        },
        {
          id: 'math',
          title: 'Number Games',
          description: 'Learn counting and basic arithmetic through games',
          icon: Calculator,
          color: 'from-green-500 to-green-600',
          progress: Math.floor((student.progress.mathLevel / 10) * 100)
        },
        {
          id: 'health',
          title: 'Healthy Habits',
          description: 'Learn about hygiene and healthy eating',
          icon: Heart,
          color: 'from-red-500 to-red-600',
          progress: 75
        }
      ];
    } else if (gradeNum <= 8) {
      return [
        {
          id: 'reading',
          title: 'Reading Comprehension',
          description: 'Advanced reading with comprehension questions',
          icon: BookOpen,
          color: 'from-blue-500 to-blue-600',
          progress: Math.floor((student.progress.readingLevel / 10) * 100)
        },
        {
          id: 'homework',
          title: 'Problem Solving',
          description: 'Get help with algebra and geometry problems',
          icon: Calculator,
          color: 'from-green-500 to-green-600',
          progress: Math.floor((student.progress.mathLevel / 10) * 100)
        },
        {
          id: 'coding',
          title: 'Programming Basics',
          description: 'Learn Python programming fundamentals',
          icon: Code,
          color: 'from-purple-500 to-purple-600',
          progress: 60
        },
        {
          id: 'science',
          title: 'Science Experiments',
          description: 'Explore physics and chemistry concepts',
          icon: Zap,
          color: 'from-orange-500 to-orange-600',
          progress: Math.floor((student.progress.scienceLevel / 10) * 100)
        }
      ];
    } else {
      return [
        {
          id: 'reading',
          title: 'Literature Analysis',
          description: 'Analyze complex texts and literary works',
          icon: BookOpen,
          color: 'from-blue-500 to-blue-600',
          progress: Math.floor((student.progress.readingLevel / 10) * 100)
        },
        {
          id: 'homework',
          title: 'Advanced Mathematics',
          description: 'Calculus, statistics, and advanced algebra',
          icon: Calculator,
          color: 'from-green-500 to-green-600',
          progress: Math.floor((student.progress.mathLevel / 10) * 100)
        },
        {
          id: 'coding',
          title: 'Software Development',
          description: 'Build real applications and websites',
          icon: Code,
          color: 'from-purple-500 to-purple-600',
          progress: 80
        },
        {
          id: 'assignments',
          title: 'Project Portfolio',
          description: 'Work on complex, multi-week projects',
          icon: Users,
          color: 'from-indigo-500 to-indigo-600',
          progress: 70
        }
      ];
    }
  };

  const quickActions = [
    ...getGradeSpecificActions()
  ];

  const achievements = [
    {
      title: 'Study Streak',
      value: `${student.progress.streakDays} days`,
      icon: TrendingUp,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Lessons Completed',
      value: `${student.progress.completedLessons}`,
      icon: Award,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Actual Study Time',
      value: `${student.progress.actualUsageTime} mins`,
      icon: Clock,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      title: 'Real Progress',
      value: `${Math.floor(calculateRealProgress())}%`,
      icon: BarChart3,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ];

  const recentActivities = [
    {
      activity: `Completed "${getGradeSpecificActions()[0]?.title}" lesson`,
      time: realTimeSession ? 'Just now' : '2 hours ago',
      type: 'lesson'
    },
    {
      activity: `Practiced ${student.grade} level reading with 95% accuracy`,
      time: '1 day ago',
      type: 'reading'
    },
    {
      activity: `Solved ${student.grade} math problems correctly`,
      time: '2 days ago',
      type: 'homework'
    },
    {
      activity: `Downloaded ${student.grade} content pack`,
      time: '3 days ago',
      type: 'download'
    }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Real-time Activity Indicator */}
      {realTimeSession?.isActive && (
        <div className="mb-4 bg-green-50 border border-green-200 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
            <span className="text-green-800 font-medium">You're actively learning right now!</span>
            <span className="text-green-600 text-sm">
              Session time: {Math.floor((new Date().getTime() - new Date(realTimeSession.startTime).getTime()) / 60000)} minutes
            </span>
          </div>
        </div>
      )}

      {/* Greeting Section */}
      <div className="mb-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">
          {greeting}, {student.name}! 👋
        </h1>
        <p className="text-blue-100 text-lg">
          Ready to continue your {student.grade} learning journey today?
        </p>
        
        {/* Progress Overview */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-blue-100">Reading Level</span>
              <span className="font-bold">{student.progress.readingLevel}/10</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2">
              <div 
                className="bg-white rounded-full h-2 transition-all duration-300"
                style={{ width: `${(student.progress.readingLevel / 10) * 100}%` }}
              />
            </div>
          </div>
          
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-blue-100">Math Level</span>
              <span className="font-bold">{student.progress.mathLevel}/10</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2">
              <div 
                className="bg-white rounded-full h-2 transition-all duration-300"
                style={{ width: `${(student.progress.mathLevel / 10) * 100}%` }}
              />
            </div>
          </div>
          
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-blue-100">Real Progress</span>
              <span className="font-bold">
                {Math.floor(calculateRealProgress())}%
              </span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2">
              <div 
                className="bg-white rounded-full h-2 transition-all duration-300"
                style={{ width: `${calculateRealProgress()}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <div className="lg:col-span-2">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            {student.grade} Learning Modules
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <div
                  key={action.id}
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-300 cursor-pointer group hover:scale-105"
                >
                  <div className={`w-12 h-12 bg-gradient-to-r ${action.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {action.title}
                  </h3>
                  
                  <p className="text-gray-600 text-sm mb-4">
                    {action.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">
                      {action.progress}% complete
                    </span>
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div 
                        className={`bg-gradient-to-r ${action.color} rounded-full h-2 transition-all duration-300`}
                        style={{ width: `${action.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Real-time Stats */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">📊 Real-time Stats</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Today's Study Time</span>
                <span className="font-semibold text-blue-600">
                  {realTimeSession ? 
                    Math.floor((new Date().getTime() - new Date(realTimeSession.startTime).getTime()) / 60000) : 0
                  } min
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Current Module</span>
                <span className="font-semibold text-green-600 capitalize">
                  {realTimeSession?.currentModule || 'Dashboard'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Status</span>
                <div className="flex items-center space-x-1">
                  <div className={`w-2 h-2 rounded-full ${realTimeSession?.isActive ? 'bg-green-500' : 'bg-gray-400'}`} />
                  <span className="text-sm font-medium">
                    {realTimeSession?.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Achievements</h3>
            <div className="space-y-4">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon;
                return (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${achievement.bgColor} rounded-lg flex items-center justify-center`}>
                      <Icon className={`h-5 w-5 ${achievement.color}`} />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{achievement.value}</p>
                      <p className="text-sm text-gray-600">{achievement.title}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
            <div className="space-y-3">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-900">{activity.activity}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Next Steps */}
          <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-6 border border-yellow-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">🎯 Next for {student.grade}</h3>
            <p className="text-sm text-gray-700 mb-4">
              Based on your {student.grade} curriculum and progress, here's what we recommend next.
            </p>
            <button className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white py-2 px-4 rounded-lg font-medium hover:from-yellow-600 hover:to-orange-600 transition-all">
              Continue {student.grade} Learning
            </button>
          </div>
        </div>
      </div>

      {/* Grade-specific Information */}
      <div className="mt-8 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          📚 {student.grade} Curriculum Overview
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 rounded-lg p-4">
            <h3 className="font-semibold text-blue-800 mb-2">Core Subjects</h3>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Mathematics (Grade {student.grade.replace('Grade ', '')} level)</li>
              <li>• Reading & Language Arts</li>
              <li>• Science Fundamentals</li>
              <li>• Health & Nutrition</li>
            </ul>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4">
            <h3 className="font-semibold text-green-800 mb-2">Skills Development</h3>
            <ul className="text-sm text-green-700 space-y-1">
              <li>• Critical thinking</li>
              <li>• Problem solving</li>
              <li>• Communication</li>
              <li>• Digital literacy</li>
            </ul>
          </div>
          
          <div className="bg-purple-50 rounded-lg p-4">
            <h3 className="font-semibold text-purple-800 mb-2">Special Features</h3>
            <ul className="text-sm text-purple-700 space-y-1">
              <li>• AI-powered tutoring</li>
              <li>• Real-time progress tracking</li>
              <li>• Plagiarism-free content</li>
              <li>• Teacher interaction</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;