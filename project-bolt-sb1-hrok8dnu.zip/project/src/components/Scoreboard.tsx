import React, { useState } from 'react';
import { Trophy, Medal, Star, TrendingUp, Award, Crown, Target } from 'lucide-react';
import { Student, ScoreboardEntry, Language } from '../types';
import { translations } from '../i18n';

interface ScoreboardProps {
  student: Student;
  currentLanguage: Language;
}

const Scoreboard: React.FC<ScoreboardProps> = ({ student, currentLanguage }) => {
  const [activeTab, setActiveTab] = useState('overall');
  const [timeFilter, setTimeFilter] = useState('all-time');

  const t = translations[currentLanguage];

  // Mock scoreboard data
  const scoreboardData: ScoreboardEntry[] = [
    {
      studentId: student.id,
      studentName: student.name,
      totalScore: 2450,
      averageScore: 87,
      completedAssignments: 28,
      rank: 3,
      badges: [
        { id: '1', name: 'Reading Master', description: 'Completed 50 reading exercises', icon: '📚', earnedAt: '2024-01-15' },
        { id: '2', name: 'Math Wizard', description: 'Solved 100 math problems', icon: '🧮', earnedAt: '2024-01-10' },
        { id: '3', name: 'Streak Champion', description: '30-day learning streak', icon: '🔥', earnedAt: '2024-01-20' }
      ]
    },
    {
      studentId: '2',
      studentName: 'Maria Santos',
      totalScore: 2890,
      averageScore: 92,
      completedAssignments: 31,
      rank: 1,
      badges: [
        { id: '4', name: 'Top Performer', description: 'Ranked #1 in class', icon: '👑', earnedAt: '2024-01-22' },
        { id: '5', name: 'Code Master', description: 'Perfect coding assignment', icon: '💻', earnedAt: '2024-01-18' },
        { id: '6', name: 'Helper', description: 'Helped 10 classmates', icon: '🤝', earnedAt: '2024-01-16' }
      ]
    },
    {
      studentId: '3',
      studentName: 'James Ochieng',
      totalScore: 2720,
      averageScore: 89,
      completedAssignments: 30,
      rank: 2,
      badges: [
        { id: '7', name: 'Science Explorer', description: 'Completed all science modules', icon: '🔬', earnedAt: '2024-01-19' },
        { id: '8', name: 'Consistent Learner', description: 'Daily login for 60 days', icon: '📅', earnedAt: '2024-01-21' }
      ]
    },
    {
      studentId: '4',
      studentName: 'Fatima Al-Rashid',
      totalScore: 2380,
      averageScore: 85,
      completedAssignments: 28,
      rank: 4,
      badges: [
        { id: '9', name: 'Language Expert', description: 'Mastered 3 languages', icon: '🌍', earnedAt: '2024-01-17' },
        { id: '10', name: 'Quick Learner', description: 'Fastest lesson completion', icon: '⚡', earnedAt: '2024-01-14' }
      ]
    },
    {
      studentId: '5',
      studentName: 'Carlos Rodriguez',
      totalScore: 2180,
      averageScore: 82,
      completedAssignments: 26,
      rank: 5,
      badges: [
        { id: '11', name: 'Problem Solver', description: 'Solved complex math problems', icon: '🧩', earnedAt: '2024-01-13' }
      ]
    }
  ];

  const subjectScoreboards = {
    math: scoreboardData.map(entry => ({
      ...entry,
      totalScore: Math.floor(entry.totalScore * 0.8),
      averageScore: Math.floor(entry.averageScore * 0.9)
    })).sort((a, b) => b.totalScore - a.totalScore),
    reading: scoreboardData.map(entry => ({
      ...entry,
      totalScore: Math.floor(entry.totalScore * 1.1),
      averageScore: Math.floor(entry.averageScore * 1.05)
    })).sort((a, b) => b.totalScore - a.totalScore),
    science: scoreboardData.map(entry => ({
      ...entry,
      totalScore: Math.floor(entry.totalScore * 0.9),
      averageScore: Math.floor(entry.averageScore * 0.95)
    })).sort((a, b) => b.totalScore - a.totalScore),
    coding: scoreboardData.map(entry => ({
      ...entry,
      totalScore: Math.floor(entry.totalScore * 1.2),
      averageScore: Math.floor(entry.averageScore * 1.1)
    })).sort((a, b) => b.totalScore - a.totalScore)
  };

  const getCurrentScoreboard = () => {
    if (activeTab === 'overall') return scoreboardData;
    return subjectScoreboards[activeTab as keyof typeof subjectScoreboards] || scoreboardData;
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-orange-500" />;
      default:
        return <Target className="h-6 w-6 text-blue-500" />;
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'from-yellow-400 to-yellow-600';
      case 2:
        return 'from-gray-300 to-gray-500';
      case 3:
        return 'from-orange-400 to-orange-600';
      default:
        return 'from-blue-400 to-blue-600';
    }
  };

  const currentStudent = getCurrentScoreboard().find(entry => entry.studentId === student.id);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Class Scoreboard</h1>
        <p className="text-gray-600">See how you rank among your classmates</p>
      </div>

      {/* Student's Current Rank */}
      {currentStudent && (
        <div className="mb-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`w-16 h-16 bg-gradient-to-r ${getRankColor(currentStudent.rank)} rounded-full flex items-center justify-center`}>
                {getRankIcon(currentStudent.rank)}
              </div>
              <div>
                <h2 className="text-2xl font-bold">Your Current Rank</h2>
                <p className="text-blue-100">#{currentStudent.rank} out of {scoreboardData.length} students</p>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-3xl font-bold">{currentStudent.totalScore}</p>
              <p className="text-blue-100">Total Points</p>
            </div>
          </div>
          
          <div className="mt-4 grid grid-cols-3 gap-4">
            <div className="bg-white/10 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold">{currentStudent.averageScore}%</p>
              <p className="text-blue-100 text-sm">Average Score</p>
            </div>
            <div className="bg-white/10 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold">{currentStudent.completedAssignments}</p>
              <p className="text-blue-100 text-sm">Completed</p>
            </div>
            <div className="bg-white/10 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold">{currentStudent.badges.length}</p>
              <p className="text-blue-100 text-sm">Badges Earned</p>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex space-x-4 mb-6 overflow-x-auto">
        {[
          { id: 'overall', label: 'Overall', icon: Trophy },
          { id: 'math', label: 'Mathematics', icon: Target },
          { id: 'reading', label: 'Reading', icon: Star },
          { id: 'science', label: 'Science', icon: Award },
          { id: 'coding', label: 'Coding', icon: Medal }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Time Filter */}
      <div className="flex items-center space-x-4 mb-6">
        <span className="text-sm font-medium text-gray-700">Time Period:</span>
        <select
          value={timeFilter}
          onChange={(e) => setTimeFilter(e.target.value)}
          className="px-3 py-1 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="all-time">All Time</option>
          <option value="this-month">This Month</option>
          <option value="this-week">This Week</option>
          <option value="today">Today</option>
        </select>
      </div>

      {/* Scoreboard */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
            <Trophy className="h-6 w-6 text-yellow-500" />
            <span>{activeTab === 'overall' ? 'Overall Rankings' : `${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Rankings`}</span>
          </h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {getCurrentScoreboard().map((entry, index) => {
            const isCurrentStudent = entry.studentId === student.id;
            
            return (
              <div
                key={entry.studentId}
                className={`p-6 transition-colors ${
                  isCurrentStudent ? 'bg-blue-50 border-l-4 border-blue-500' : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 bg-gradient-to-r ${getRankColor(entry.rank)} rounded-full flex items-center justify-center text-white font-bold text-lg`}>
                      {entry.rank}
                    </div>
                    
                    <div>
                      <h3 className={`text-lg font-semibold ${isCurrentStudent ? 'text-blue-900' : 'text-gray-900'}`}>
                        {entry.studentName}
                        {isCurrentStudent && <span className="text-blue-600 ml-2">(You)</span>}
                      </h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>{entry.completedAssignments} assignments completed</span>
                        <span>{entry.badges.length} badges earned</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-2xl font-bold text-gray-900">{entry.totalScore}</p>
                    <p className="text-sm text-gray-600">Total Points</p>
                    <p className="text-lg font-semibold text-green-600">{entry.averageScore}%</p>
                    <p className="text-xs text-gray-500">Average</p>
                  </div>
                </div>
                
                {/* Badges */}
                {entry.badges.length > 0 && (
                  <div className="mt-4 flex flex-wrap gap-2">
                    {entry.badges.slice(0, 3).map((badge) => (
                      <div
                        key={badge.id}
                        className="flex items-center space-x-1 bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium"
                        title={badge.description}
                      >
                        <span>{badge.icon}</span>
                        <span>{badge.name}</span>
                      </div>
                    ))}
                    {entry.badges.length > 3 && (
                      <div className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs font-medium">
                        +{entry.badges.length - 3} more
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Achievement Gallery */}
      <div className="mt-8 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center space-x-2">
          <Star className="h-6 w-6 text-yellow-500" />
          <span>Your Achievement Gallery</span>
        </h2>
        
        {currentStudent && currentStudent.badges.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {currentStudent.badges.map((badge) => (
              <div key={badge.id} className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-lg p-4 border border-yellow-200">
                <div className="text-center">
                  <div className="text-4xl mb-2">{badge.icon}</div>
                  <h3 className="font-semibold text-gray-900">{badge.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">{badge.description}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    Earned on {new Date(badge.earnedAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Award className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No badges yet</h3>
            <p className="text-gray-600">Complete lessons and assignments to earn your first badge!</p>
          </div>
        )}
      </div>

      {/* Leaderboard Stats */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <TrendingUp className="h-5 w-5 text-green-500" />
            <span className="font-medium text-gray-900">Your Progress</span>
          </div>
          <p className="text-2xl font-bold text-green-600">
            {Math.round((student.progress.completedLessons / student.progress.totalLessons) * 100)}%
          </p>
          <p className="text-sm text-gray-600">Course completion</p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span className="font-medium text-gray-900">Class Rank</span>
          </div>
          <p className="text-2xl font-bold text-yellow-600">#{currentStudent?.rank || 'N/A'}</p>
          <p className="text-sm text-gray-600">Out of {scoreboardData.length}</p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <Star className="h-5 w-5 text-purple-500" />
            <span className="font-medium text-gray-900">Badges</span>
          </div>
          <p className="text-2xl font-bold text-purple-600">{currentStudent?.badges.length || 0}</p>
          <p className="text-sm text-gray-600">Achievements</p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <Award className="h-5 w-5 text-blue-500" />
            <span className="font-medium text-gray-900">Total Score</span>
          </div>
          <p className="text-2xl font-bold text-blue-600">{currentStudent?.totalScore || 0}</p>
          <p className="text-sm text-gray-600">Points earned</p>
        </div>
      </div>

      {/* Motivation Section */}
      <div className="mt-8 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">🎯 Keep Going!</h3>
        <p className="text-gray-700 mb-4">
          {currentStudent?.rank === 1 
            ? "Congratulations! You're at the top of the class. Keep up the excellent work!"
            : currentStudent?.rank && currentStudent.rank <= 3
            ? "You're in the top 3! A little more effort could get you to #1."
            : "Every lesson completed brings you closer to the top. Keep learning!"
          }
        </p>
        
        <div className="flex items-center space-x-4">
          <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition-colors">
            Continue Learning
          </button>
          <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors">
            View Progress Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default Scoreboard;