import React, { useState, useEffect } from 'react';
import { Activity, Clock, Wifi } from 'lucide-react';
import { RealTimeSession } from '../types';

interface RealTimeTrackerProps {
  session: RealTimeSession | null;
}

const RealTimeTracker: React.FC<RealTimeTrackerProps> = ({ session }) => {
  const [sessionTime, setSessionTime] = useState(0);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    if (session?.isActive) {
      setIsActive(true);
      const startTime = new Date(session.startTime).getTime();
      
      const interval = setInterval(() => {
        const now = new Date().getTime();
        const elapsed = Math.floor((now - startTime) / 1000 / 60); // minutes
        setSessionTime(elapsed);
      }, 1000);

      return () => clearInterval(interval);
    } else {
      setIsActive(false);
    }
  }, [session]);

  if (!session) return null;

  return (
    <div className="flex items-center space-x-2 bg-green-50 px-3 py-1 rounded-full border border-green-200">
      <div className="flex items-center space-x-1">
        <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
        <Wifi className="h-3 w-3 text-green-600" />
      </div>
      
      <div className="flex items-center space-x-1 text-xs text-green-700">
        <Clock className="h-3 w-3" />
        <span>{sessionTime}m</span>
      </div>
      
      <div className="text-xs text-green-600 font-medium">
        {session.currentModule}
      </div>
    </div>
  );
};

export default RealTimeTracker;