import React, { useState } from 'react';
import { Code, Play, CheckCircle, Clock, Trophy, Zap, Target } from 'lucide-react';
import { Student, Language } from '../types';
import { translations } from '../i18n';

interface CodingChallengesProps {
  student: Student;
  currentLanguage: Language;
}

const CodingChallenges: React.FC<CodingChallengesProps> = ({ student, currentLanguage }) => {
  const [activeChallenge, setActiveChallenge] = useState<any>(null);
  const [code, setCode] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [output, setOutput] = useState('');
  const [completedChallenges, setCompletedChallenges] = useState<Set<string>>(new Set());

  const t = translations[currentLanguage];

  // Grade-specific coding challenges
  const getGradeChallenges = (grade: string) => {
    const gradeNum = parseInt(grade.replace('Grade ', ''));
    
    if (gradeNum <= 5) {
      return [
        {
          id: 'basic-1',
          title: 'Hello World',
          description: 'Write your first program that prints "Hello, World!"',
          difficulty: 'beginner',
          language: 'python',
          starterCode: '# Write your code here\nprint("Hello, World!")',
          expectedOutput: 'Hello, World!',
          hints: ['Use the print() function', 'Put your text in quotes'],
          points: 10
        },
        {
          id: 'basic-2',
          title: 'Simple Math',
          description: 'Calculate and print the sum of two numbers',
          difficulty: 'beginner',
          language: 'python',
          starterCode: '# Calculate 5 + 3\na = 5\nb = 3\n# Print the result',
          expectedOutput: '8',
          hints: ['Use the + operator', 'Store the result in a variable'],
          points: 15
        }
      ];
    } else if (gradeNum <= 8) {
      return [
        {
          id: 'intermediate-1',
          title: 'Number Guessing Game',
          description: 'Create a simple number guessing game',
          difficulty: 'intermediate',
          language: 'python',
          starterCode: 'import random\n\n# Generate a random number between 1 and 10\nsecret_number = random.randint(1, 10)\n\n# Your code here',
          expectedOutput: 'Game logic with user interaction',
          hints: ['Use input() to get user guess', 'Use if/else for comparison', 'Add a loop for multiple attempts'],
          points: 25
        },
        {
          id: 'intermediate-2',
          title: 'List Operations',
          description: 'Work with lists to store and manipulate data',
          difficulty: 'intermediate',
          language: 'python',
          starterCode: '# Create a list of your favorite subjects\nsubjects = []\n\n# Add subjects to the list\n# Print the list',
          expectedOutput: 'List with subjects',
          hints: ['Use append() to add items', 'Use len() to get list length', 'Use for loop to iterate'],
          points: 20
        }
      ];
    } else {
      return [
        {
          id: 'advanced-1',
          title: 'Data Analysis',
          description: 'Analyze student grade data and calculate statistics',
          difficulty: 'advanced',
          language: 'python',
          starterCode: '# Student grades data\ngrades = [85, 92, 78, 96, 88, 91, 84, 89]\n\n# Calculate average, highest, and lowest grades\n# Your code here',
          expectedOutput: 'Statistical analysis of grades',
          hints: ['Use sum() and len() for average', 'Use max() and min() functions', 'Consider using functions'],
          points: 35
        },
        {
          id: 'advanced-2',
          title: 'Web Scraper',
          description: 'Build a simple web scraper to extract educational content',
          difficulty: 'advanced',
          language: 'python',
          starterCode: 'import requests\nfrom bs4 import BeautifulSoup\n\n# Your web scraping code here',
          expectedOutput: 'Extracted web content',
          hints: ['Use requests.get() to fetch pages', 'Parse HTML with BeautifulSoup', 'Handle errors gracefully'],
          points: 50
        }
      ];
    }
  };

  const challenges = getGradeChallenges(student.grade);

  const runCode = async () => {
    setIsRunning(true);
    setOutput('');
    
    // Simulate code execution
    setTimeout(() => {
      // Simple code evaluation simulation
      if (code.includes('print(')) {
        const printMatch = code.match(/print\((.*?)\)/);
        if (printMatch) {
          try {
            const content = printMatch[1].replace(/['"]/g, '');
            setOutput(content);
          } catch {
            setOutput('Hello, World!');
          }
        }
      } else if (code.includes('sum') || code.includes('+')) {
        setOutput('8');
      } else {
        setOutput('Code executed successfully!');
      }
      
      setIsRunning(false);
      
      // Mark challenge as completed if output matches expected
      if (activeChallenge && output.includes(activeChallenge.expectedOutput.substring(0, 5))) {
        setCompletedChallenges(prev => new Set([...prev, activeChallenge.id]));
      }
    }, 2000);
  };

  const resetChallenge = () => {
    if (activeChallenge) {
      setCode(activeChallenge.starterCode);
      setOutput('');
    }
  };

  if (activeChallenge) {
    const isCompleted = completedChallenges.has(activeChallenge.id);
    
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={() => setActiveChallenge(null)}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              ← Back to Challenges
            </button>
            
            <div className="flex items-center space-x-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                activeChallenge.difficulty === 'beginner' 
                  ? 'bg-green-100 text-green-800'
                  : activeChallenge.difficulty === 'intermediate'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {activeChallenge.difficulty}
              </span>
              
              <div className="flex items-center space-x-1">
                <Trophy className="h-4 w-4 text-yellow-500" />
                <span className="text-sm font-medium">{activeChallenge.points} points</span>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{activeChallenge.title}</h1>
            <p className="text-gray-600">{activeChallenge.description}</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Code Editor */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-gray-900">Code Editor</h3>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={resetChallenge}
                    className="text-gray-600 hover:text-gray-800 text-sm"
                  >
                    Reset
                  </button>
                  <span className="text-sm text-gray-500">Python</span>
                </div>
              </div>
              
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full h-64 p-4 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-gray-900 text-green-400"
                placeholder="Write your code here..."
              />
              
              <button
                onClick={runCode}
                disabled={isRunning || !code.trim()}
                className="mt-3 flex items-center space-x-2 bg-green-500 hover:bg-green-600 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              >
                {isRunning ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                    <span>Running...</span>
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    <span>Run Code</span>
                  </>
                )}
              </button>
            </div>
            
            {/* Output & Instructions */}
            <div className="space-y-4">
              {/* Instructions */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Instructions</h3>
                <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                  <p className="text-gray-700 mb-3">{activeChallenge.description}</p>
                  
                  <div className="mb-3">
                    <h4 className="font-semibold text-gray-900 mb-2">💡 Hints:</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      {activeChallenge.hints.map((hint: string, index: number) => (
                        <li key={index} className="flex items-start space-x-2">
                          <span className="text-blue-500">•</span>
                          <span>{hint}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Expected Output:</h4>
                    <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                      {activeChallenge.expectedOutput}
                    </code>
                  </div>
                </div>
              </div>
              
              {/* Output */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Output</h3>
                <div className="bg-gray-900 text-green-400 rounded-lg p-4 font-mono text-sm min-h-32">
                  {output || 'Run your code to see the output...'}
                </div>
              </div>
              
              {/* Success Message */}
              {isCompleted && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="font-semibold text-green-800">Challenge Completed! 🎉</span>
                  </div>
                  <p className="text-green-700 text-sm">
                    Great job! You've earned {activeChallenge.points} points.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Coding Challenges</h1>
        <p className="text-gray-600">Learn programming through hands-on challenges tailored to your grade level</p>
      </div>

      {/* Progress Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <span className="font-medium text-gray-900">Completed</span>
          </div>
          <p className="text-2xl font-bold text-green-600 mt-1">{completedChallenges.size}</p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2">
            <Target className="h-5 w-5 text-blue-500" />
            <span className="font-medium text-gray-900">Available</span>
          </div>
          <p className="text-2xl font-bold text-blue-600 mt-1">{challenges.length}</p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span className="font-medium text-gray-900">Points Earned</span>
          </div>
          <p className="text-2xl font-bold text-yellow-600 mt-1">
            {Array.from(completedChallenges).reduce((total, challengeId) => {
              const challenge = challenges.find(c => c.id === challengeId);
              return total + (challenge?.points || 0);
            }, 0)}
          </p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-purple-500" />
            <span className="font-medium text-gray-900">Skill Level</span>
          </div>
          <p className="text-2xl font-bold text-purple-600 mt-1">
            {completedChallenges.size === 0 ? 'Beginner' : 
             completedChallenges.size < 3 ? 'Learning' : 
             completedChallenges.size < 5 ? 'Intermediate' : 'Advanced'}
          </p>
        </div>
      </div>

      {/* Grade-Specific Notice */}
      <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="font-semibold text-blue-800 mb-2">
          📚 {student.grade} Coding Curriculum
        </h3>
        <p className="text-blue-700 text-sm">
          These challenges are specifically designed for your grade level, focusing on age-appropriate programming concepts and problem-solving skills.
        </p>
      </div>

      {/* Challenges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {challenges.map((challenge) => {
          const isCompleted = completedChallenges.has(challenge.id);
          
          return (
            <div
              key={challenge.id}
              className={`bg-white rounded-xl p-6 shadow-sm border transition-all cursor-pointer hover:shadow-md ${
                isCompleted 
                  ? 'border-green-200 bg-green-50' 
                  : 'border-gray-100 hover:border-blue-300'
              }`}
              onClick={() => {
                setActiveChallenge(challenge);
                setCode(challenge.starterCode);
                setOutput('');
              }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">{challenge.title}</h3>
                  <p className="text-gray-600 text-sm">{challenge.description}</p>
                </div>
                
                {isCompleted && (
                  <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0 ml-2" />
                )}
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    challenge.difficulty === 'beginner' 
                      ? 'bg-green-100 text-green-700'
                      : challenge.difficulty === 'intermediate'
                      ? 'bg-yellow-100 text-yellow-700'
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {challenge.difficulty}
                  </span>
                  
                  <span className="text-gray-500">{challenge.language}</span>
                </div>
                
                <div className="flex items-center space-x-1 text-yellow-600">
                  <Trophy className="h-4 w-4" />
                  <span className="font-medium">{challenge.points}pts</span>
                </div>
              </div>
              
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center space-x-1 text-gray-500">
                  <Code className="h-4 w-4" />
                  <span className="text-sm">Interactive Coding</span>
                </div>
                
                <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 font-medium">
                  <Play className="h-4 w-4" />
                  <span>Start Challenge</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Learning Path */}
      <div className="mt-8 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Coding Journey</h2>
        
        <div className="flex items-center space-x-4 overflow-x-auto pb-4">
          {challenges.map((challenge, index) => {
            const isCompleted = completedChallenges.has(challenge.id);
            const isCurrent = !isCompleted && challenges.slice(0, index).every(c => completedChallenges.has(c.id));
            
            return (
              <div key={challenge.id} className="flex items-center space-x-2 flex-shrink-0">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${
                  isCompleted 
                    ? 'bg-green-500 text-white' 
                    : isCurrent 
                    ? 'bg-blue-500 text-white animate-pulse' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {isCompleted ? <CheckCircle className="h-5 w-5" /> : index + 1}
                </div>
                
                {index < challenges.length - 1 && (
                  <div className={`w-8 h-1 ${
                    isCompleted ? 'bg-green-500' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
        
        <div className="mt-4 text-center">
          <p className="text-gray-600">
            Complete challenges in order to unlock advanced programming concepts
          </p>
        </div>
      </div>

      {/* Tips for Success */}
      <div className="mt-8 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 border border-purple-200">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">🚀 Coding Tips for Success</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">For Beginners:</h3>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Start with simple print statements</li>
              <li>• Practice typing code character by character</li>
              <li>• Don't worry about making mistakes - they help you learn!</li>
              <li>• Read error messages carefully for clues</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">For Advanced Learners:</h3>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Break complex problems into smaller steps</li>
              <li>• Use functions to organize your code</li>
              <li>• Add comments to explain your thinking</li>
              <li>• Test your code with different inputs</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CodingChallenges;