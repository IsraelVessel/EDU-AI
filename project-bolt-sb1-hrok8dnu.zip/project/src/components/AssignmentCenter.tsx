import React, { useState } from 'react';
import { Github, Plus, Calendar, Clock, CheckCircle, AlertCircle, ExternalLink, Upload } from 'lucide-react';
import { Student, Teacher, Assignment, Language } from '../types';
import { translations } from '../i18n';

interface AssignmentCenterProps {
  currentLanguage: Language;
  student?: Student;
  teacher?: Teacher;
}

const AssignmentCenter: React.FC<AssignmentCenterProps> = ({ currentLanguage, student, teacher }) => {
  const [activeTab, setActiveTab] = useState(student ? 'my-assignments' : 'create');
  const [assignments, setAssignments] = useState<Assignment[]>([
    {
      id: '1',
      title: 'Basic Python Calculator',
      description: 'Create a simple calculator that can perform basic arithmetic operations (addition, subtraction, multiplication, division)',
      subject: 'Computer Science',
      grade: 'Grade 8',
      dueDate: '2024-02-15T23:59:59Z',
      githubRepoUrl: 'https://github.com/eduai-assignments/python-calculator-template',
      maxScore: 100,
      submissions: [],
      autoGrading: true,
      rubric: [
        { criteria: 'Code Functionality', maxPoints: 40, description: 'Calculator performs all required operations correctly' },
        { criteria: 'Code Quality', maxPoints: 30, description: 'Clean, readable, and well-structured code' },
        { criteria: 'Documentation', maxPoints: 20, description: 'Clear comments and README file' },
        { criteria: 'Testing', maxPoints: 10, description: 'Includes basic test cases' }
      ]
    },
    {
      id: '2',
      title: 'Math Problem Solver',
      description: 'Build a program that solves quadratic equations and shows step-by-step solutions',
      subject: 'Mathematics',
      grade: 'Grade 9',
      dueDate: '2024-02-20T23:59:59Z',
      githubRepoUrl: 'https://github.com/eduai-assignments/quadratic-solver-template',
      maxScore: 100,
      submissions: [],
      autoGrading: true,
      rubric: [
        { criteria: 'Mathematical Accuracy', maxPoints: 50, description: 'Correctly solves quadratic equations' },
        { criteria: 'User Interface', maxPoints: 25, description: 'Clear and intuitive interface' },
        { criteria: 'Error Handling', maxPoints: 15, description: 'Handles invalid inputs gracefully' },
        { criteria: 'Code Organization', maxPoints: 10, description: 'Well-organized and modular code' }
      ]
    }
  ]);

  const [newAssignment, setNewAssignment] = useState({
    title: '',
    description: '',
    subject: '',
    grade: '',
    dueDate: '',
    githubRepoUrl: '',
    maxScore: 100,
    autoGrading: true
  });

  const t = translations[currentLanguage];

  const createAssignment = () => {
    const assignment: Assignment = {
      id: Date.now().toString(),
      ...newAssignment,
      submissions: [],
      rubric: [
        { criteria: 'Functionality', maxPoints: 40, description: 'Code works as expected' },
        { criteria: 'Quality', maxPoints: 30, description: 'Clean and readable code' },
        { criteria: 'Documentation', maxPoints: 20, description: 'Proper documentation' },
        { criteria: 'Testing', maxPoints: 10, description: 'Includes test cases' }
      ]
    };
    
    setAssignments(prev => [assignment, ...prev]);
    setNewAssignment({
      title: '',
      description: '',
      subject: '',
      grade: '',
      dueDate: '',
      githubRepoUrl: '',
      maxScore: 100,
      autoGrading: true
    });
  };

  const submitAssignment = (assignmentId: string) => {
    // Simulate GitHub submission
    const submission = {
      id: Date.now().toString(),
      studentId: student?.id || '',
      assignmentId,
      githubPullRequestUrl: `https://github.com/${student?.githubUsername}/assignment-${assignmentId}/pull/1`,
      submittedAt: new Date().toISOString(),
      teacherReviewed: false,
      autoGradedReport: {
        overallScore: Math.floor(Math.random() * 30) + 70,
        codeQuality: Math.floor(Math.random() * 30) + 70,
        functionality: Math.floor(Math.random() * 30) + 70,
        documentation: Math.floor(Math.random() * 30) + 70,
        testCoverage: Math.floor(Math.random() * 30) + 70,
        feedback: [
          'Good use of functions and modular design',
          'Consider adding more error handling',
          'Documentation could be more detailed'
        ],
        suggestions: [
          'Add input validation for edge cases',
          'Consider using type hints for better code clarity',
          'Add more comprehensive test cases'
        ]
      }
    };

    setAssignments(prev => prev.map(assignment => 
      assignment.id === assignmentId 
        ? { ...assignment, submissions: [...assignment.submissions, submission] }
        : assignment
    ));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(currentLanguage, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getDaysUntilDue = (dueDate: string) => {
    const now = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const renderStudentView = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <span className="font-medium text-gray-900">Completed</span>
          </div>
          <p className="text-2xl font-bold text-green-600 mt-1">
            {assignments.filter(a => a.submissions.some(s => s.studentId === student?.id)).length}
          </p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-orange-500" />
            <span className="font-medium text-gray-900">Pending</span>
          </div>
          <p className="text-2xl font-bold text-orange-600 mt-1">
            {assignments.filter(a => !a.submissions.some(s => s.studentId === student?.id)).length}
          </p>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            <span className="font-medium text-gray-900">Overdue</span>
          </div>
          <p className="text-2xl font-bold text-red-600 mt-1">
            {assignments.filter(a => 
              !a.submissions.some(s => s.studentId === student?.id) && 
              getDaysUntilDue(a.dueDate) < 0
            ).length}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {assignments.map((assignment) => {
          const isSubmitted = assignment.submissions.some(s => s.studentId === student?.id);
          const submission = assignment.submissions.find(s => s.studentId === student?.id);
          const daysUntilDue = getDaysUntilDue(assignment.dueDate);
          const isOverdue = daysUntilDue < 0 && !isSubmitted;
          
          return (
            <div key={assignment.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{assignment.title}</h3>
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                      {assignment.subject}
                    </span>
                    <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">
                      {assignment.grade}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 mb-3">{assignment.description}</p>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>Due: {formatDate(assignment.dueDate)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span className={`font-medium ${
                        isOverdue ? 'text-red-600' : daysUntilDue <= 2 ? 'text-orange-600' : 'text-green-600'
                      }`}>
                        {isOverdue ? `${Math.abs(daysUntilDue)} days overdue` : 
                         daysUntilDue === 0 ? 'Due today' : 
                         `${daysUntilDue} days left`}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col items-end space-y-2">
                  {isSubmitted ? (
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span className="text-green-600 font-medium">Submitted</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <AlertCircle className={`h-5 w-5 ${isOverdue ? 'text-red-500' : 'text-orange-500'}`} />
                      <span className={`font-medium ${isOverdue ? 'text-red-600' : 'text-orange-600'}`}>
                        {isOverdue ? 'Overdue' : 'Pending'}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <a
                  href={assignment.githubRepoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 font-medium"
                >
                  <Github className="h-4 w-4" />
                  <span>View Template</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
                
                {!isSubmitted ? (
                  <button
                    onClick={() => submitAssignment(assignment.id)}
                    disabled={!student?.githubUsername}
                    className="flex items-center space-x-2 bg-green-500 hover:bg-green-600 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                  >
                    <Upload className="h-4 w-4" />
                    <span>Submit via GitHub</span>
                  </button>
                ) : (
                  <div className="space-y-2">
                    {submission?.autoGradedReport && (
                      <div className="text-right">
                        <p className="text-sm text-gray-600">Auto-graded Score:</p>
                        <p className="text-lg font-bold text-green-600">
                          {submission.autoGradedReport.overallScore}/100
                        </p>
                      </div>
                    )}
                    <a
                      href={submission?.githubPullRequestUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 font-medium text-sm"
                    >
                      <Github className="h-4 w-4" />
                      <span>View Submission</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
              </div>
              
              {submission?.autoGradedReport && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Automated Feedback</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                    <div className="text-center">
                      <p className="text-lg font-bold text-blue-600">{submission.autoGradedReport.functionality}%</p>
                      <p className="text-xs text-gray-600">Functionality</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-green-600">{submission.autoGradedReport.codeQuality}%</p>
                      <p className="text-xs text-gray-600">Code Quality</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-purple-600">{submission.autoGradedReport.documentation}%</p>
                      <p className="text-xs text-gray-600">Documentation</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-orange-600">{submission.autoGradedReport.testCoverage}%</p>
                      <p className="text-xs text-gray-600">Test Coverage</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Feedback:</p>
                      <ul className="text-sm text-gray-600 list-disc list-inside">
                        {submission.autoGradedReport.feedback.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium text-gray-700">Suggestions for Improvement:</p>
                      <ul className="text-sm text-gray-600 list-disc list-inside">
                        {submission.autoGradedReport.suggestions.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderTeacherView = () => (
    <div className="space-y-6">
      {activeTab === 'create' && (
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Assignment</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Assignment Title</label>
              <input
                type="text"
                value={newAssignment.title}
                onChange={(e) => setNewAssignment(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., Python Data Structures"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
              <select
                value={newAssignment.subject}
                onChange={(e) => setNewAssignment(prev => ({ ...prev, subject: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select subject</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Science">Science</option>
                <option value="English">English</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Target Grade</label>
              <select
                value={newAssignment.grade}
                onChange={(e) => setNewAssignment(prev => ({ ...prev, grade: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select grade</option>
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={`Grade ${i + 1}`}>Grade {i + 1}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Due Date</label>
              <input
                type="datetime-local"
                value={newAssignment.dueDate}
                onChange={(e) => setNewAssignment(prev => ({ ...prev, dueDate: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">GitHub Repository Template</label>
              <input
                type="url"
                value={newAssignment.githubRepoUrl}
                onChange={(e) => setNewAssignment(prev => ({ ...prev, githubRepoUrl: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="https://github.com/your-org/assignment-template"
              />
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
              <textarea
                value={newAssignment.description}
                onChange={(e) => setNewAssignment(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Describe the assignment requirements, learning objectives, and deliverables..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Maximum Score</label>
              <input
                type="number"
                value={newAssignment.maxScore}
                onChange={(e) => setNewAssignment(prev => ({ ...prev, maxScore: parseInt(e.target.value) }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                min="1"
                max="1000"
              />
            </div>
            
            <div className="flex items-center">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={newAssignment.autoGrading}
                  onChange={(e) => setNewAssignment(prev => ({ ...prev, autoGrading: e.target.checked }))}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Enable Auto-Grading</span>
              </label>
            </div>
          </div>
          
          <button
            onClick={createAssignment}
            disabled={!newAssignment.title || !newAssignment.description || !newAssignment.subject}
            className="mt-4 flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-400 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Create Assignment</span>
          </button>
        </div>
      )}
      
      {activeTab === 'submissions' && (
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Review Submissions</h3>
          
          <div className="space-y-4">
            {assignments.map((assignment) => (
              <div key={assignment.id} className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-2">{assignment.title}</h4>
                <p className="text-sm text-gray-600 mb-3">
                  {assignment.submissions.length} submission(s)
                </p>
                
                {assignment.submissions.map((submission) => (
                  <div key={submission.id} className="bg-gray-50 rounded-lg p-3 mb-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900">Student ID: {submission.studentId}</p>
                        <p className="text-sm text-gray-600">
                          Submitted: {formatDate(submission.submittedAt)}
                        </p>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        {submission.autoGradedReport && (
                          <span className="text-lg font-bold text-green-600">
                            {submission.autoGradedReport.overallScore}/100
                          </span>
                        )}
                        <a
                          href={submission.githubPullRequestUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center space-x-1 text-blue-600 hover:text-blue-800"
                        >
                          <Github className="h-4 w-4" />
                          <span>Review</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {student ? 'My Assignments' : 'Assignment Center'}
        </h1>
        <p className="text-gray-600">
          {student 
            ? 'Complete coding assignments and submit via GitHub' 
            : 'Create and manage coding assignments with automated grading'
          }
        </p>
      </div>

      {teacher && (
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setActiveTab('create')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'create'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Create Assignment
          </button>
          <button
            onClick={() => setActiveTab('submissions')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === 'submissions'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Review Submissions
          </button>
        </div>
      )}

      {student ? renderStudentView() : renderTeacherView()}

      {/* GitHub Integration Info */}
      <div className="mt-8 bg-gray-900 text-white rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Github className="h-8 w-8" />
          <div>
            <h3 className="text-lg font-semibold">GitHub Integration</h3>
            <p className="text-gray-300 text-sm">Professional development workflow</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div>
            <h4 className="font-semibold mb-2">1. Fork Template</h4>
            <p className="text-gray-300">Students fork the assignment repository template</p>
          </div>
          <div>
            <h4 className="font-semibold mb-2">2. Code & Commit</h4>
            <p className="text-gray-300">Complete the assignment and commit changes</p>
          </div>
          <div>
            <h4 className="font-semibold mb-2">3. Submit PR</h4>
            <p className="text-gray-300">Create pull request for automated review</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssignmentCenter;