import React, { useState } from 'react';
import { Users, BookOpen, TrendingUp, Settings, Download, Plus, Eye, BarChart3, Github, MessageSquare, Award } from 'lucide-react';
import { Language, ProgressData, Teacher, Student } from '../types';

interface TeacherDashboardProps {
  currentLanguage: Language;
  teacher: Teacher;
  activeTab?: string;
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ currentLanguage, teacher, activeTab: propActiveTab }) => {
  const [activeTab, setActiveTab] = useState(propActiveTab || 'overview');

  // Mock student data for the teacher
  const students: Student[] = [
    {
      id: '1',
      name: 'Maria Santos',
      email: 'maria@student.edu',
      grade: 'Grade 8',
      preferredLanguage: 'es',
      teacherId: teacher.id,
      githubUsername: 'maria-santos-student',
      joinDate: '2024-01-10',
      progress: {
        readingLevel: 7,
        mathLevel: 6,
        scienceLevel: 7,
        completedLessons: 45,
        totalLessons: 100,
        streakDays: 12,
        actualUsageTime: 340,
        lastActiveTime: '2024-01-22T14:30:00Z',
        gradeSpecificProgress: { 'Grade 8': 75 }
      },
      assignments: [],
      realTimeActivity: []
    },
    {
      id: '2',
      name: 'James Ochieng',
      email: 'james@student.edu',
      grade: 'Grade 7',
      preferredLanguage: 'sw',
      teacherId: teacher.id,
      githubUsername: 'james-ochieng-dev',
      joinDate: '2024-01-08',
      progress: {
        readingLevel: 8,
        mathLevel: 9,
        scienceLevel: 8,
        completedLessons: 62,
        totalLessons: 100,
        streakDays: 18,
        actualUsageTime: 520,
        lastActiveTime: '2024-01-22T16:45:00Z',
        gradeSpecificProgress: { 'Grade 7': 82 }
      },
      assignments: [],
      realTimeActivity: []
    },
    {
      id: '3',
      name: 'Fatima Al-Rashid',
      email: 'fatima@student.edu',
      grade: 'Grade 9',
      preferredLanguage: 'ar',
      githubUsername: 'fatima-coding',
      joinDate: '2024-01-12',
      progress: {
        readingLevel: 9,
        mathLevel: 7,
        scienceLevel: 9,
        completedLessons: 38,
        totalLessons: 100,
        streakDays: 8,
        actualUsageTime: 280,
        lastActiveTime: '2024-01-22T11:20:00Z',
        gradeSpecificProgress: { 'Grade 9': 68 }
      },
      assignments: [],
      realTimeActivity: []
    }
  ];

  const classStats = {
    totalStudents: students.length,
    averageProgress: Math.round(students.reduce((acc, s) => acc + (s.progress.completedLessons / s.progress.totalLessons) * 100, 0) / students.length),
    lessonsCompleted: students.reduce((acc, s) => acc + s.progress.completedLessons, 0),
    averageReadingLevel: Math.round(students.reduce((acc, s) => acc + s.progress.readingLevel, 0) / students.length),
    averageMathLevel: Math.round(students.reduce((acc, s) => acc + s.progress.mathLevel, 0) / students.length),
    totalStudyTime: students.reduce((acc, s) => acc + s.progress.actualUsageTime, 0),
    activeStudents: students.filter(s => {
      const lastActive = new Date(s.progress.lastActiveTime);
      const now = new Date();
      const diffHours = (now.getTime() - lastActive.getTime()) / (1000 * 60 * 60);
      return diffHours < 24;
    }).length
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Teacher Profile Card */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-6 text-white">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center text-2xl font-bold">
            {teacher.profile.avatar ? (
              <img src={teacher.profile.avatar} alt={teacher.name} className="w-16 h-16 rounded-full object-cover" />
            ) : (
              teacher.name.charAt(0)
            )}
          </div>
          <div>
            <h2 className="text-2xl font-bold">{teacher.name}</h2>
            <p className="text-blue-100">{teacher.subject} • {teacher.school}</p>
            <p className="text-blue-200 text-sm">{teacher.profile.experience} years experience</p>
          </div>
        </div>
        
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div className="bg-white/10 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold">{classStats.totalStudents}</p>
            <p className="text-blue-100 text-sm">Students</p>
          </div>
          <div className="bg-white/10 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold">{classStats.activeStudents}</p>
            <p className="text-blue-100 text-sm">Active Today</p>
          </div>
          <div className="bg-white/10 rounded-lg p-3 text-center">
            <p className="text-2xl font-bold">{Math.floor(classStats.totalStudyTime / 60)}h</p>
            <p className="text-blue-100 text-sm">Total Study Time</p>
          </div>
        </div>
      </div>

      {/* Class Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3">
            <Users className="h-8 w-8 text-blue-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{classStats.totalStudents}</p>
              <p className="text-sm text-gray-600">Total Students</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3">
            <TrendingUp className="h-8 w-8 text-green-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{classStats.averageProgress}%</p>
              <p className="text-sm text-gray-600">Avg Progress</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3">
            <BookOpen className="h-8 w-8 text-purple-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{classStats.lessonsCompleted}</p>
              <p className="text-sm text-gray-600">Lessons Done</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3">
            <BookOpen className="h-8 w-8 text-blue-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{classStats.averageReadingLevel}/10</p>
              <p className="text-sm text-gray-600">Avg Reading</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3">
            <TrendingUp className="h-8 w-8 text-orange-500" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{classStats.averageMathLevel}/10</p>
              <p className="text-sm text-gray-600">Avg Math</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <button className="flex items-center space-x-2 p-4 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors">
            <Plus className="h-5 w-5" />
            <span>Add New Student</span>
          </button>
          <button className="flex items-center space-x-2 p-4 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors">
            <BookOpen className="h-5 w-5" />
            <span>Create Assignment</span>
          </button>
          <button className="flex items-center space-x-2 p-4 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors">
            <Download className="h-5 w-5" />
            <span>Export Reports</span>
          </button>
          <button className="flex items-center space-x-2 p-4 bg-orange-50 text-orange-700 rounded-lg hover:bg-orange-100 transition-colors">
            <Eye className="h-5 w-5" />
            <span>View Analytics</span>
          </button>
        </div>
      </div>

      {/* Real-time Student Activity */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">📊 Real-time Student Activity</h3>
        <div className="space-y-3">
          {students.map((student) => {
            const isActive = new Date().getTime() - new Date(student.progress.lastActiveTime).getTime() < 30 * 60 * 1000; // Active in last 30 minutes
            
            return (
              <div key={student.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    {student.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{student.name}</p>
                    <p className="text-xs text-gray-500">
                      {isActive ? 'Active now' : `Last seen ${Math.floor((new Date().getTime() - new Date(student.progress.lastActiveTime).getTime()) / (1000 * 60 * 60))}h ago`}
                    </p>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{Math.floor(student.progress.actualUsageTime / 60)}h {student.progress.actualUsageTime % 60}m</p>
                  <p className="text-xs text-gray-500">Study time</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Class Activity */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Class Activity</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                M
              </div>
              <div>
                <p className="text-sm font-medium">Maria Santos completed "Grade 8 Algebra Basics"</p>
                <p className="text-xs text-gray-500">2 hours ago • Real-time tracked</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-green-600">95%</p>
              <p className="text-xs text-gray-500">Score</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                J
              </div>
              <div>
                <p className="text-sm font-medium">James Ochieng submitted GitHub assignment</p>
                <p className="text-xs text-gray-500">4 hours ago • Auto-graded: 88/100</p>
              </div>
            </div>
            <a
              href="https://github.com/james-ochieng-dev/python-calculator/pull/1"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-1 text-blue-600 hover:text-blue-800"
            >
              <Github className="h-4 w-4" />
              <span className="text-sm">Review</span>
            </a>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                F
              </div>
              <div>
                <p className="text-sm font-medium">Fatima Al-Rashid achieved 30-day streak</p>
                <p className="text-xs text-gray-500">6 hours ago • Badge earned</p>
              </div>
            </div>
            <Award className="h-5 w-5 text-yellow-500" />
          </div>
        </div>
      </div>
    </div>
  );

  const renderStudents = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Student Management</h3>
        <button className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors">
          <Plus className="h-4 w-4" />
          <span>Add Student</span>
        </button>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Grade
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Real Progress
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Study Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Active
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  GitHub
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {students.map((student) => {
                const realProgress = (student.progress.completedLessons / student.progress.totalLessons) * 100;
                const isActive = new Date().getTime() - new Date(student.progress.lastActiveTime).getTime() < 30 * 60 * 1000;
                
                return (
                  <tr key={student.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                          {student.name.charAt(0)}
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">{student.name}</p>
                          <div className="flex items-center space-x-1">
                            <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500' : 'bg-gray-400'}`} />
                            <span className="text-xs text-gray-500">
                              {isActive ? 'Online' : 'Offline'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {student.grade}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${realProgress}%` }}
                          />
                        </div>
                        <span className="ml-2 text-sm text-gray-500">{Math.floor(realProgress)}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {Math.floor(student.progress.actualUsageTime / 60)}h {student.progress.actualUsageTime % 60}m
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(student.progress.lastActiveTime).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {student.githubUsername ? (
                        <a
                          href={`https://github.com/${student.githubUsername}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center space-x-1 text-blue-600 hover:text-blue-800"
                        >
                          <Github className="h-4 w-4" />
                          <span className="text-sm">{student.githubUsername}</span>
                        </a>
                      ) : (
                        <span className="text-sm text-gray-400">Not connected</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button className="text-blue-600 hover:text-blue-900 mr-2">View</button>
                      <button className="text-green-600 hover:text-green-900 mr-2">Message</button>
                      <button className="text-gray-600 hover:text-gray-900">Grade</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-gray-900">Advanced Analytics</h3>
      
      {/* Real-time Engagement */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Real-time Engagement Metrics</h4>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-2xl font-bold text-green-600">{classStats.activeStudents}</p>
            <p className="text-sm text-green-700">Active Now</p>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-2xl font-bold text-blue-600">{Math.floor(classStats.totalStudyTime / classStats.totalStudents)}</p>
            <p className="text-sm text-blue-700">Avg Minutes/Student</p>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <p className="text-2xl font-bold text-purple-600">
              {Math.floor(students.reduce((acc, s) => acc + s.progress.streakDays, 0) / students.length)}
            </p>
            <p className="text-sm text-purple-700">Avg Streak Days</p>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <p className="text-2xl font-bold text-orange-600">
              {Math.floor((students.filter(s => s.progress.actualUsageTime > 0).length / students.length) * 100)}%
            </p>
            <p className="text-sm text-orange-700">Engagement Rate</p>
          </div>
        </div>
      </div>

      {/* Grade-wise Performance */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Performance by Grade Level</h4>
        <div className="space-y-4">
          {['Grade 7', 'Grade 8', 'Grade 9'].map((grade) => {
            const gradeStudents = students.filter(s => s.grade === grade);
            const avgProgress = gradeStudents.length > 0 
              ? gradeStudents.reduce((acc, s) => acc + (s.progress.completedLessons / s.progress.totalLessons) * 100, 0) / gradeStudents.length
              : 0;
            
            return (
              <div key={grade} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{grade}</p>
                  <p className="text-sm text-gray-600">{gradeStudents.length} students</p>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${avgProgress}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-900">{Math.floor(avgProgress)}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* GitHub Integration Stats */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">GitHub Assignment Analytics</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-900 text-white rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Github className="h-5 w-5" />
              <span className="font-medium">Connected Students</span>
            </div>
            <p className="text-2xl font-bold">
              {students.filter(s => s.githubUsername).length}/{students.length}
            </p>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="font-medium text-green-800">Auto-graded</span>
            </div>
            <p className="text-2xl font-bold text-green-600">12</p>
            <p className="text-sm text-green-700">Assignments this week</p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <BarChart3 className="h-5 w-5 text-blue-600" />
              <span className="font-medium text-blue-800">Avg Score</span>
            </div>
            <p className="text-2xl font-bold text-blue-600">87%</p>
            <p className="text-sm text-blue-700">Class average</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Grade-Specific Content Library</h3>
        <button className="flex items-center space-x-2 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors">
          <Plus className="h-4 w-4" />
          <span>Create Content</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {['Grade 7', 'Grade 8', 'Grade 9'].map((grade) => (
          <div key={grade} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center space-x-3 mb-4">
              <BookOpen className="h-8 w-8 text-blue-500" />
              <div>
                <h4 className="text-lg font-semibold text-gray-900">{grade} Content</h4>
                <p className="text-sm text-gray-600">Age-appropriate curriculum</p>
              </div>
            </div>
            
            <div className="space-y-2 text-sm text-gray-700">
              <p>• {grade === 'Grade 7' ? 'Basic algebra and geometry' : 
                   grade === 'Grade 8' ? 'Intermediate algebra and functions' : 
                   'Advanced algebra and trigonometry'}</p>
              <p>• {grade === 'Grade 7' ? 'Simple coding concepts' : 
                   grade === 'Grade 8' ? 'Python programming basics' : 
                   'Web development and databases'}</p>
              <p>• {grade === 'Grade 7' ? 'Basic science principles' : 
                   grade === 'Grade 8' ? 'Chemistry and physics intro' : 
                   'Advanced scientific concepts'}</p>
            </div>
            
            <button className="mt-4 w-full bg-blue-50 text-blue-700 py-2 px-4 rounded-lg hover:bg-blue-100 transition-colors">
              Manage {grade} Content
            </button>
          </div>
        ))}
      </div>

      {/* Auto-Generated Content */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">AI-Generated Practice Content</h4>
        <p className="text-gray-600 mb-4">
          Generate plagiarism-free, grade-specific practice exercises using our AI content engine.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button className="flex items-center space-x-2 p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors">
            <BookOpen className="h-5 w-5 text-blue-500" />
            <div className="text-left">
              <p className="font-medium text-gray-900">Generate Reading Exercises</p>
              <p className="text-sm text-gray-600">Create grade-appropriate reading materials</p>
            </div>
          </button>
          
          <button className="flex items-center space-x-2 p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:bg-green-50 transition-colors">
            <TrendingUp className="h-5 w-5 text-green-500" />
            <div className="text-left">
              <p className="font-medium text-gray-900">Generate Math Problems</p>
              <p className="text-sm text-gray-600">Create practice problems by grade level</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'overview', label: 'Class Overview', icon: BarChart3 },
    { id: 'students', label: 'Student Management', icon: Users },
    { id: 'content', label: 'Content Library', icon: BookOpen },
    { id: 'analytics', label: 'Advanced Analytics', icon: TrendingUp },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return renderOverview();
      case 'students':
        return renderStudents();
      case 'content':
        return renderContent();
      case 'analytics':
        return renderAnalytics();
      case 'settings':
        return renderSettings();
      default:
        return renderOverview();
    }
  };

  const renderSettings = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-gray-900">Teacher Settings</h3>
      
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Profile Settings</h4>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Display Name</label>
            <input
              type="text"
              defaultValue={teacher.name}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
            <input
              type="text"
              defaultValue={teacher.subject}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">School</label>
            <input
              type="text"
              defaultValue={teacher.school}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
            <textarea
              defaultValue={teacher.profile.bio}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Class Management</h4>
        <div className="space-y-3">
          <label className="flex items-center">
            <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            <span className="ml-2 text-sm text-gray-700">Allow students to see real-time progress</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            <span className="ml-2 text-sm text-gray-700">Enable auto-grading for assignments</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            <span className="ml-2 text-sm text-gray-700">Send daily progress reports to parents</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            <span className="ml-2 text-sm text-gray-700">Allow student-teacher messaging</span>
          </label>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <h1 className="text-2xl font-bold text-gray-900">Teacher Dashboard</h1>
        <p className="text-gray-600">Manage your classes and track real-time student progress</p>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white shadow-sm min-h-screen">
          <div className="p-4">
            <div className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 text-left rounded-lg transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {renderTabContent()}
        </main>
      </div>
    </div>
  );
};

export default TeacherDashboard;