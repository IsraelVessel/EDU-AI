import React, { useState } from 'react';
import { GraduationCap, MessageSquare, Star, Users, BookOpen, Mail, Github } from 'lucide-react';
import { Student, Teacher, Language, TeacherStudentInteraction } from '../types';
import { translations } from '../i18n';

interface TeacherDirectoryProps {
  student: Student;
  currentLanguage: Language;
}

const TeacherDirectory: React.FC<TeacherDirectoryProps> = ({ student, currentLanguage }) => {
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);
  const [messageText, setMessageText] = useState('');
  const [interactions, setInteractions] = useState<TeacherStudentInteraction[]>([]);

  const t = translations[currentLanguage];

  // Mock teacher data
  const teachers: Teacher[] = [
    {
      id: 't1',
      name: 'Dr. Sarah Johnson',
      email: 'sarah.johnson@school.edu',
      subject: 'Mathematics',
      school: 'Global Learning Academy',
      githubUsername: 'sarah-math-teacher',
      joinDate: '2023-09-01',
      students: [student.id],
      classes: [],
      profile: {
        bio: 'Passionate mathematics educator with 8 years of experience. I believe every student can excel in math with the right approach and support.',
        experience: 8,
        qualifications: ['PhD in Mathematics Education', 'Master of Science in Mathematics', 'Teaching Certificate'],
        avatar: 'https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
      }
    },
    {
      id: 't2',
      name: 'Prof. Michael Chen',
      email: 'michael.chen@school.edu',
      subject: 'Computer Science',
      school: 'Global Learning Academy',
      githubUsername: 'prof-chen-cs',
      joinDate: '2023-08-15',
      students: [],
      classes: [],
      profile: {
        bio: 'Computer Science professor and software engineer. I love teaching programming and helping students build real-world projects.',
        experience: 12,
        qualifications: ['PhD in Computer Science', 'Industry Software Engineer', 'Google Certified Educator'],
        avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
      }
    },
    {
      id: 't3',
      name: 'Ms. Amara Okafor',
      email: 'amara.okafor@school.edu',
      subject: 'Science',
      school: 'Global Learning Academy',
      githubUsername: 'amara-science',
      joinDate: '2023-09-10',
      students: [student.id],
      classes: [],
      profile: {
        bio: 'Science educator focused on making complex concepts accessible. I use hands-on experiments and real-world applications to bring science to life.',
        experience: 6,
        qualifications: ['Master of Science in Biology', 'Environmental Science Certificate', 'STEM Education Specialist'],
        avatar: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
      }
    },
    {
      id: 't4',
      name: 'Mr. Jean-Pierre Dubois',
      email: 'jean.dubois@school.edu',
      subject: 'Health Education',
      school: 'Global Learning Academy',
      githubUsername: 'jp-health-ed',
      joinDate: '2023-08-20',
      students: [],
      classes: [],
      profile: {
        bio: 'Health educator and former nurse. I teach students about nutrition, hygiene, and wellness practices that can transform communities.',
        experience: 10,
        qualifications: ['Master in Public Health', 'Registered Nurse', 'Community Health Specialist'],
        avatar: 'https://images.pexels.com/photos/2182975/pexels-photo-2182975.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
      }
    }
  ];

  const sendMessage = (teacherId: string) => {
    if (!messageText.trim()) return;
    
    const interaction: TeacherStudentInteraction = {
      id: Date.now().toString(),
      teacherId,
      studentId: student.id,
      type: 'message',
      content: messageText,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    
    setInteractions(prev => [interaction, ...prev]);
    setMessageText('');
  };

  const connectWithTeacher = (teacherId: string) => {
    // Simulate connecting with teacher
    const interaction: TeacherStudentInteraction = {
      id: Date.now().toString(),
      teacherId,
      studentId: student.id,
      type: 'message',
      content: `Hi! I'm ${student.name} from ${student.grade}. I'd like to connect with you for learning support.`,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    
    setInteractions(prev => [interaction, ...prev]);
  };

  const getSubjectIcon = (subject: string) => {
    switch (subject.toLowerCase()) {
      case 'mathematics':
        return '🧮';
      case 'computer science':
        return '💻';
      case 'science':
        return '🔬';
      case 'health education':
        return '🏥';
      case 'english':
        return '📚';
      default:
        return '📖';
    }
  };

  const getExperienceLevel = (years: number) => {
    if (years < 3) return { level: 'New Educator', color: 'text-green-600' };
    if (years < 7) return { level: 'Experienced', color: 'text-blue-600' };
    if (years < 12) return { level: 'Senior Educator', color: 'text-purple-600' };
    return { level: 'Master Educator', color: 'text-yellow-600' };
  };

  if (selectedTeacher) {
    const teacherInteractions = interactions.filter(i => i.teacherId === selectedTeacher.id);
    const experienceInfo = getExperienceLevel(selectedTeacher.profile.experience);
    
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
          {/* Back Button */}
          <button
            onClick={() => setSelectedTeacher(null)}
            className="text-blue-600 hover:text-blue-800 font-medium mb-6"
          >
            ← Back to Teachers
          </button>
          
          {/* Teacher Profile */}
          <div className="flex items-start space-x-6 mb-8">
            <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
              {selectedTeacher.profile.avatar ? (
                <img
                  src={selectedTeacher.profile.avatar}
                  alt={selectedTeacher.name}
                  className="w-24 h-24 rounded-full object-cover"
                />
              ) : (
                selectedTeacher.name.charAt(0)
              )}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h1 className="text-2xl font-bold text-gray-900">{selectedTeacher.name}</h1>
                <span className="text-2xl">{getSubjectIcon(selectedTeacher.subject)}</span>
              </div>
              
              <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                <span className="font-medium">{selectedTeacher.subject}</span>
                <span>•</span>
                <span>{selectedTeacher.school}</span>
                <span>•</span>
                <span className={`font-medium ${experienceInfo.color}`}>
                  {experienceInfo.level}
                </span>
              </div>
              
              <p className="text-gray-700 mb-4">{selectedTeacher.profile.bio}</p>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <Users className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{selectedTeacher.students.length} students</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm text-gray-600">{selectedTeacher.profile.experience} years experience</span>
                </div>
                <a
                  href={`https://github.com/${selectedTeacher.githubUsername}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-1 text-blue-600 hover:text-blue-800"
                >
                  <Github className="h-4 w-4" />
                  <span className="text-sm">GitHub</span>
                </a>
              </div>
            </div>
          </div>
          
          {/* Qualifications */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Qualifications</h3>
            <div className="flex flex-wrap gap-2">
              {selectedTeacher.profile.qualifications.map((qual, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
                >
                  {qual}
                </span>
              ))}
            </div>
          </div>
          
          {/* Message Section */}
          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Send Message</h3>
            
            <div className="space-y-4">
              <textarea
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Ask a question or request help..."
              />
              
              <button
                onClick={() => sendMessage(selectedTeacher.id)}
                disabled={!messageText.trim()}
                className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-400 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                <MessageSquare className="h-4 w-4" />
                <span>Send Message</span>
              </button>
            </div>
            
            {/* Message History */}
            {teacherInteractions.length > 0 && (
              <div className="mt-6">
                <h4 className="font-semibold text-gray-900 mb-3">Message History</h4>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {teacherInteractions.map((interaction) => (
                    <div key={interaction.id} className="bg-gray-50 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium text-gray-900">You</span>
                        <span className="text-xs text-gray-500">
                          {new Date(interaction.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700">{interaction.content}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">My Teachers</h1>
        <p className="text-gray-600">Connect with your teachers and get personalized support</p>
      </div>

      {/* My Connected Teachers */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Connected Teachers</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {teachers.filter(teacher => teacher.students.includes(student.id)).map((teacher) => {
            const experienceInfo = getExperienceLevel(teacher.profile.experience);
            
            return (
              <div key={teacher.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all">
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold">
                    {teacher.profile.avatar ? (
                      <img
                        src={teacher.profile.avatar}
                        alt={teacher.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                    ) : (
                      teacher.name.charAt(0)
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h3 className="text-lg font-semibold text-gray-900">{teacher.name}</h3>
                      <span className="text-lg">{getSubjectIcon(teacher.subject)}</span>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-2">{teacher.subject} • {teacher.school}</p>
                    <p className={`text-sm font-medium ${experienceInfo.color} mb-2`}>
                      {experienceInfo.level}
                    </p>
                    
                    <p className="text-sm text-gray-700 mb-3 line-clamp-2">
                      {teacher.profile.bio}
                    </p>
                    
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setSelectedTeacher(teacher)}
                        className="flex items-center space-x-1 bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-lg text-sm font-medium transition-colors"
                      >
                        <MessageSquare className="h-3 w-3" />
                        <span>Message</span>
                      </button>
                      
                      <button
                        onClick={() => setSelectedTeacher(teacher)}
                        className="flex items-center space-x-1 bg-gray-500 hover:bg-gray-600 text-white px-3 py-1 rounded-lg text-sm font-medium transition-colors"
                      >
                        <BookOpen className="h-3 w-3" />
                        <span>View Profile</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Available Teachers */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Available Teachers</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {teachers.filter(teacher => !teacher.students.includes(student.id)).map((teacher) => {
            const experienceInfo = getExperienceLevel(teacher.profile.experience);
            
            return (
              <div key={teacher.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all">
                <div className="text-center mb-4">
                  <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-3">
                    {teacher.profile.avatar ? (
                      <img
                        src={teacher.profile.avatar}
                        alt={teacher.name}
                        className="w-20 h-20 rounded-full object-cover"
                      />
                    ) : (
                      teacher.name.charAt(0)
                    )}
                  </div>
                  
                  <div className="flex items-center justify-center space-x-2 mb-1">
                    <h3 className="text-lg font-semibold text-gray-900">{teacher.name}</h3>
                    <span className="text-lg">{getSubjectIcon(teacher.subject)}</span>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-1">{teacher.subject}</p>
                  <p className={`text-sm font-medium ${experienceInfo.color} mb-2`}>
                    {experienceInfo.level}
                  </p>
                </div>
                
                <p className="text-sm text-gray-700 mb-4 text-center line-clamp-3">
                  {teacher.profile.bio}
                </p>
                
                <div className="flex items-center justify-center space-x-2 mb-4">
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-600">{teacher.students.length} students</span>
                  </div>
                  <span className="text-gray-400">•</span>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm text-gray-600">{teacher.profile.experience}y exp</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <button
                    onClick={() => connectWithTeacher(teacher.id)}
                    className="w-full bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg font-medium transition-colors"
                  >
                    Connect with Teacher
                  </button>
                  
                  <button
                    onClick={() => setSelectedTeacher(teacher)}
                    className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg font-medium transition-colors"
                  >
                    View Full Profile
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Interactions */}
      {interactions.length > 0 && (
        <div className="mt-8 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Interactions</h2>
          <div className="space-y-3">
            {interactions.slice(0, 5).map((interaction) => {
              const teacher = teachers.find(t => t.id === interaction.teacherId);
              
              return (
                <div key={interaction.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    {teacher?.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-medium text-gray-900">To: {teacher?.name}</span>
                      <span className="text-xs text-gray-500">
                        {new Date(interaction.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700">{interaction.content}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Help Section */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="font-semibold text-blue-800 mb-2">💡 How to Connect with Teachers</h3>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Browse available teachers by subject and experience</li>
          <li>• Send connection requests to teachers you'd like to learn from</li>
          <li>• Ask questions about assignments, concepts, or career guidance</li>
          <li>• Teachers can see your progress and provide personalized feedback</li>
          <li>• Build meaningful mentor-student relationships</li>
        </ul>
      </div>
    </div>
  );
};

export default TeacherDirectory;