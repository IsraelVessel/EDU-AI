import React, { useState } from 'react';
import { Star, MessageSquare, Send, ThumbsUp, ThumbsDown, AlertCircle } from 'lucide-react';
import { Student, Teacher, UserFeedback, Language } from '../types';
import { translations } from '../i18n';

interface FeedbackSystemProps {
  currentLanguage: Language;
  userType: 'student' | 'teacher';
  user: Student | Teacher;
}

const FeedbackSystem: React.FC<FeedbackSystemProps> = ({ currentLanguage, userType, user }) => {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');
  const [category, setCategory] = useState<'content' | 'usability' | 'features' | 'performance'>('content');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedFeedback, setSubmittedFeedback] = useState<UserFeedback[]>([]);

  const t = translations[currentLanguage];

  const categories = [
    { id: 'content', label: 'Content Quality', icon: '📚' },
    { id: 'usability', label: 'User Experience', icon: '🎨' },
    { id: 'features', label: 'Features', icon: '⚡' },
    { id: 'performance', label: 'Performance', icon: '🚀' }
  ];

  const submitFeedback = async () => {
    if (rating === 0 || !comment.trim()) return;
    
    setIsSubmitting(true);
    
    const feedback: UserFeedback = {
      id: Date.now().toString(),
      userId: user.id,
      userType,
      rating,
      comment: comment.trim(),
      category,
      submittedAt: new Date().toISOString(),
      status: 'pending'
    };
    
    // Simulate API submission
    setTimeout(() => {
      setSubmittedFeedback(prev => [feedback, ...prev]);
      setRating(0);
      setComment('');
      setIsSubmitting(false);
    }, 1000);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(currentLanguage, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getRatingColor = (stars: number) => {
    if (stars >= 4) return 'text-green-500';
    if (stars >= 3) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium">Pending Review</span>;
      case 'reviewed':
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">Under Review</span>;
      case 'resolved':
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">Resolved</span>;
      default:
        return null;
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Feedback & Suggestions</h1>
          <p className="text-gray-600">Help us improve EduAI by sharing your experience</p>
        </div>

        {/* Feedback Form */}
        <div className="mb-8 bg-gray-50 rounded-xl p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Share Your Feedback</h2>
          
          <div className="space-y-4">
            {/* Category Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Feedback Category</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setCategory(cat.id as any)}
                    className={`flex items-center space-x-2 p-3 rounded-lg border transition-colors ${
                      category === cat.id
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <span>{cat.icon}</span>
                    <span className="text-sm font-medium">{cat.label}</span>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Rating */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Overall Rating</label>
              <div className="flex items-center space-x-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoveredRating(star)}
                    onMouseLeave={() => setHoveredRating(0)}
                    className="p-1 transition-colors"
                  >
                    <Star
                      className={`h-8 w-8 ${
                        star <= (hoveredRating || rating)
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
                <span className="ml-2 text-sm text-gray-600">
                  {rating > 0 && (
                    <span className={getRatingColor(rating)}>
                      {rating === 5 ? 'Excellent!' : 
                       rating === 4 ? 'Good' : 
                       rating === 3 ? 'Average' : 
                       rating === 2 ? 'Poor' : 'Very Poor'}
                    </span>
                  )}
                </span>
              </div>
            </div>
            
            {/* Comment */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Your Comments</label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Tell us about your experience, suggestions for improvement, or any issues you've encountered..."
              />
              <p className="text-xs text-gray-500 mt-1">{comment.length}/500 characters</p>
            </div>
            
            {/* Submit Button */}
            <button
              onClick={submitFeedback}
              disabled={rating === 0 || !comment.trim() || isSubmitting}
              className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-400 text-white px-6 py-3 rounded-lg font-medium transition-colors"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  <span>Submit Feedback</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Previous Feedback */}
        {submittedFeedback.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Previous Feedback</h2>
            <div className="space-y-4">
              {submittedFeedback.map((feedback) => (
                <div key={feedback.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`h-4 w-4 ${
                              star <= feedback.rating
                                ? 'text-yellow-400 fill-current'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium text-gray-700 capitalize">
                        {feedback.category}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {getStatusBadge(feedback.status)}
                      <span className="text-xs text-gray-500">
                        {formatDate(feedback.submittedAt)}
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 text-sm">{feedback.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick Feedback Options */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Feedback</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:bg-green-50 transition-colors">
              <ThumbsUp className="h-6 w-6 text-green-500" />
              <div className="text-left">
                <p className="font-medium text-gray-900">Something works great!</p>
                <p className="text-sm text-gray-600">Tell us what you love about EduAI</p>
              </div>
            </button>
            
            <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-colors">
              <ThumbsDown className="h-6 w-6 text-red-500" />
              <div className="text-left">
                <p className="font-medium text-gray-900">Something needs improvement</p>
                <p className="text-sm text-gray-600">Help us fix issues or add features</p>
              </div>
            </button>
          </div>
        </div>

        {/* Feature Requests */}
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 border border-purple-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <AlertCircle className="h-6 w-6 text-purple-600" />
            <span>Suggest New Features</span>
          </h2>
          
          <p className="text-gray-700 mb-4">
            Have an idea for a new feature? We'd love to hear it! Your suggestions help us build better educational tools.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-2">🎮 Gamification</h3>
              <p className="text-sm text-gray-600">More games, challenges, and rewards</p>
            </div>
            <div className="bg-white rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-2">🤖 AI Tutoring</h3>
              <p className="text-sm text-gray-600">Personal AI tutor for each subject</p>
            </div>
            <div className="bg-white rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-2">📱 Mobile App</h3>
              <p className="text-sm text-gray-600">Native mobile application</p>
            </div>
          </div>
        </div>

        {/* Community Guidelines */}
        <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h3 className="font-semibold text-yellow-800 mb-2">📋 Feedback Guidelines</h3>
          <ul className="text-sm text-yellow-700 space-y-1">
            <li>• Be specific about what you liked or didn't like</li>
            <li>• Suggest concrete improvements when possible</li>
            <li>• Keep feedback constructive and respectful</li>
            <li>• Report bugs with steps to reproduce the issue</li>
            <li>• All feedback is reviewed by our education team</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default FeedbackSystem;