import React, { useState, useEffect } from 'react';
import { BookOpen, Users, Settings, LogOut, User, GraduationCap } from 'lucide-react';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import ReadingCoach from './components/ReadingCoach';
import HomeworkHelper from './components/HomeworkHelper';
import CrossSDGLessons from './components/CrossSDGLessons';
import TeacherDashboard from './components/TeacherDashboard';
import OfflineContent from './components/OfflineContent';
import ParentCommunication from './components/ParentCommunication';
import LanguageSelector from './components/LanguageSelector';
import AssignmentCenter from './components/AssignmentCenter';
import Scoreboard from './components/Scoreboard';
import TeacherDirectory from './components/TeacherDirectory';
import RealTimeTracker from './components/RealTimeTracker';
import FeedbackSystem from './components/FeedbackSystem';
import CodingChallenges from './components/CodingChallenges';
import { Student, Teacher, Language } from './types';
import './i18n';

function App() {
  const [currentUser, setCurrentUser] = useState<Student | Teacher | null>(null);
  const [userType, setUserType] = useState<'student' | 'teacher'>('student');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');
  const [realTimeSession, setRealTimeSession] = useState<any>(null);

  // Check for existing session on app load
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    const savedUserType = localStorage.getItem('userType');
    const savedLanguage = localStorage.getItem('currentLanguage');
    
    if (savedUser && savedUserType) {
      setCurrentUser(JSON.parse(savedUser));
      setUserType(savedUserType as 'student' | 'teacher');
    }
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage as Language);
    }
  }, []);

  // Real-time session tracking
  useEffect(() => {
    if (currentUser) {
      const session = {
        userId: currentUser.id,
        startTime: new Date().toISOString(),
        currentModule: activeTab,
        isActive: true,
        heartbeat: new Date().toISOString()
      };
      setRealTimeSession(session);

      // Update heartbeat every 30 seconds
      const interval = setInterval(() => {
        setRealTimeSession((prev: any) => ({
          ...prev,
          heartbeat: new Date().toISOString(),
          currentModule: activeTab
        }));
      }, 30000);

      return () => clearInterval(interval);
    }
  }, [currentUser, activeTab]);

  const handleLogin = (user: Student | Teacher, type: 'student' | 'teacher') => {
    setCurrentUser(user);
    setUserType(type);
    localStorage.setItem('currentUser', JSON.stringify(user));
    localStorage.setItem('userType', type);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userType');
    setActiveTab('dashboard');
    setRealTimeSession(null);
  };

  const handleLanguageChange = (language: Language) => {
    setCurrentLanguage(language);
    localStorage.setItem('currentLanguage', language);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    const greetings = {
      en: {
        morning: 'Good morning',
        afternoon: 'Good afternoon',
        evening: 'Good evening'
      },
      es: {
        morning: 'Buenos días',
        afternoon: 'Buenas tardes',
        evening: 'Buenas noches'
      },
      fr: {
        morning: 'Bonjour',
        afternoon: 'Bon après-midi',
        evening: 'Bonsoir'
      },
      sw: {
        morning: 'Habari za asubuhi',
        afternoon: 'Habari za mchana',
        evening: 'Habari za jioni'
      },
      ar: {
        morning: 'صباح الخير',
        afternoon: 'مساء الخير',
        evening: 'مساء الخير'
      },
      pt: {
        morning: 'Bom dia',
        afternoon: 'Boa tarde',
        evening: 'Boa noite'
      },
      hi: {
        morning: 'सुप्रभात',
        afternoon: 'शुभ दोपहर',
        evening: 'शुभ संध्या'
      }
    };

    let timeOfDay = 'morning';
    if (hour >= 12 && hour < 18) timeOfDay = 'afternoon';
    else if (hour >= 18) timeOfDay = 'evening';

    return greetings[currentLanguage][timeOfDay as keyof typeof greetings['en']];
  };

  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} currentLanguage={currentLanguage} onLanguageChange={handleLanguageChange} />;
  }

  const studentNavigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BookOpen },
    { id: 'reading', label: 'Reading Coach', icon: BookOpen },
    { id: 'homework', label: 'Homework Helper', icon: Users },
    { id: 'coding', label: 'Coding Challenges', icon: GraduationCap },
    { id: 'lessons', label: 'Life Skills', icon: BookOpen },
    { id: 'assignments', label: 'Assignments', icon: Settings },
    { id: 'scoreboard', label: 'Scoreboard', icon: Users },
    { id: 'teachers', label: 'My Teachers', icon: GraduationCap },
    { id: 'offline', label: 'Offline Content', icon: Settings },
    { id: 'feedback', label: 'Feedback', icon: Users },
  ];

  const teacherNavigationItems = [
    { id: 'dashboard', label: 'Teacher Dashboard', icon: BookOpen },
    { id: 'students', label: 'My Students', icon: Users },
    { id: 'assignments', label: 'Assignment Center', icon: Settings },
    { id: 'analytics', label: 'Analytics', icon: BookOpen },
    { id: 'content', label: 'Content Library', icon: BookOpen },
    { id: 'communication', label: 'Parent Communication', icon: Users },
    { id: 'feedback', label: 'Feedback', icon: Users },
  ];

  const navigationItems = userType === 'teacher' ? teacherNavigationItems : studentNavigationItems;

  const renderContent = () => {
    if (userType === 'teacher') {
      switch (activeTab) {
        case 'dashboard':
          return <TeacherDashboard currentLanguage={currentLanguage} teacher={currentUser as Teacher} />;
        case 'students':
          return <TeacherDashboard currentLanguage={currentLanguage} teacher={currentUser as Teacher} activeTab="students" />;
        case 'assignments':
          return <AssignmentCenter currentLanguage={currentLanguage} teacher={currentUser as Teacher} />;
        case 'analytics':
          return <TeacherDashboard currentLanguage={currentLanguage} teacher={currentUser as Teacher} activeTab="analytics" />;
        case 'content':
          return <TeacherDashboard currentLanguage={currentLanguage} teacher={currentUser as Teacher} activeTab="content" />;
        case 'communication':
          return <ParentCommunication student={null} teacher={currentUser as Teacher} currentLanguage={currentLanguage} />;
        case 'feedback':
          return <FeedbackSystem currentLanguage={currentLanguage} userType="teacher" user={currentUser} />;
        default:
          return <TeacherDashboard currentLanguage={currentLanguage} teacher={currentUser as Teacher} />;
      }
    } else {
      switch (activeTab) {
        case 'dashboard':
          return <Dashboard student={currentUser as Student} greeting={getGreeting()} currentLanguage={currentLanguage} realTimeSession={realTimeSession} />;
        case 'reading':
          return <ReadingCoach student={currentUser as Student} currentLanguage={currentLanguage} />;
        case 'homework':
          return <HomeworkHelper student={currentUser as Student} currentLanguage={currentLanguage} />;
        case 'coding':
          return <CodingChallenges student={currentUser as Student} currentLanguage={currentLanguage} />;
        case 'lessons':
          return <CrossSDGLessons student={currentUser as Student} currentLanguage={currentLanguage} />;
        case 'assignments':
          return <AssignmentCenter currentLanguage={currentLanguage} student={currentUser as Student} />;
        case 'scoreboard':
          return <Scoreboard student={currentUser as Student} currentLanguage={currentLanguage} />;
        case 'teachers':
          return <TeacherDirectory student={currentUser as Student} currentLanguage={currentLanguage} />;
        case 'offline':
          return <OfflineContent student={currentUser as Student} currentLanguage={currentLanguage} />;
        case 'feedback':
          return <FeedbackSystem currentLanguage={currentLanguage} userType="student" user={currentUser} />;
        default:
          return <Dashboard student={currentUser as Student} greeting={getGreeting()} currentLanguage={currentLanguage} realTimeSession={realTimeSession} />;
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <div>
                <span className="text-2xl font-bold text-gray-900">EduAI</span>
                <p className="text-xs text-gray-500 hidden sm:block">Education in Every Pocket</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <RealTimeTracker session={realTimeSession} />
              
              <LanguageSelector 
                currentLanguage={currentLanguage} 
                onLanguageChange={handleLanguageChange} 
              />
              
              <div className="flex items-center space-x-2">
                {userType === 'teacher' ? (
                  <GraduationCap className="h-5 w-5 text-blue-500" />
                ) : (
                  <User className="h-5 w-5 text-gray-400" />
                )}
                <span className="text-sm font-medium text-gray-700">{currentUser.name}</span>
                <span className="text-xs text-gray-500 capitalize">({userType})</span>
              </div>
              
              <button
                onClick={handleLogout}
                className="flex items-center space-x-1 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar Navigation */}
        <nav className="w-64 bg-white shadow-sm min-h-[calc(100vh-4rem)] sticky top-16">
          <div className="p-4">
            <div className="space-y-2">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 text-left rounded-lg transition-colors ${
                      activeTab === item.id
                        ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}
            </div>
            
            {/* Tagline */}
            <div className="mt-8 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
              <p className="text-sm font-medium text-blue-800 text-center">
                "Education in Every Pocket"
              </p>
              <p className="text-xs text-blue-600 text-center mt-1">
                Plagiarism-free, original content
              </p>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;